import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef } from "react";
import { Heart, Map, Volume2, VolumeX } from "lucide-react";
import { mountGame } from "@/game/night-run";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    return mountGame(el);
  }, []);

  return (
    <div ref={ref} className="game-root">
      <div className="stage">
        <canvas id="game-canvas" className="game-canvas" width={384} height={216} />
      </div>

      <div id="hud" className="hud is-hidden">
        <div className="hud-top">
          <div className="mission-card panel">
            <p id="mission-kicker" className="kicker">
              Миссия 1/6
            </p>
            <p id="mission-text" className="mission-text">
              Возьми пейджер
            </p>
          </div>
          <div className="stat-col">
            <div className="stat panel">
              <p id="money-val" className="money-val">
                $0
              </p>
              <div className="hp-row">
                <Heart size={14} aria-hidden="true" />
                <div className="hp-track">
                  <div id="hp-fill" className="hp-fill" />
                </div>
                <p id="hp-num" className="hp-num">
                  100
                </p>
              </div>
            </div>
            <div className="icon-row">
              <button id="sound-btn" type="button" className="icon-btn sound-btn" aria-label="Звук">
                <Volume2 className="icon-on" aria-hidden="true" />
                <VolumeX className="icon-off" aria-hidden="true" />
              </button>
              <button id="map-btn" type="button" className="icon-btn" aria-label="Карта">
                <Map size={18} aria-hidden="true" />
              </button>
              <button id="touch-toggle" type="button" className="icon-btn text-btn" aria-label="Стик">
                Стик
              </button>
            </div>
          </div>
        </div>
        <div className="minimap-wrap panel">
          <canvas id="minimap" className="minimap" width={108} height={92} />
          <p className="map-caption">карта</p>
        </div>
        <p id="hint" className="hint panel is-hidden" />
        <p id="banner" className="banner panel is-hidden" />
      </div>

      <div id="dialog" className="dialog panel is-hidden">
        <canvas id="portrait" className="portrait" width={32} height={32} />
        <div className="dlg-copy">
          <p id="dlg-name" className="dlg-name">
            Кекс
          </p>
          <p id="dlg-text" className="dlg-text" />
        </div>
        <button id="dlg-next" type="button" className="dlg-next">
          Дальше
        </button>
      </div>

      <div id="touch-ui" className="touch is-hidden">
        <div id="joy" className="joy" aria-hidden="true">
          <div id="joy-knob" className="joy-knob" />
        </div>
        <div className="touch-actions">
          <div className="pad-row">
            <button id="btn-horn" type="button" className="pad pad-small is-hidden">
              Гудок
            </button>
            <button id="btn-brake" type="button" className="pad pad-small is-hidden">
              Тормоз
            </button>
          </div>
          <button id="btn-act" type="button" className="pad">
            Войти
          </button>
          <button id="btn-atk" type="button" className="pad pad-atk">
            Удар
          </button>
        </div>
      </div>

      <div id="fade" className="fade" />

      <div id="map-overlay" className="overlay is-hidden">
        <div className="map-card panel">
          <div className="map-head">
            <h2>Район, река, лес</h2>
            <button id="close-map" type="button" className="btn-ghost">
              Закрыть
            </button>
          </div>
          <canvas id="bigmap" className="bigmap" width={344} height={288} />
          <p className="fine">Жёлтая точка — ты. Ромб — цель. Повторное нажатие на миникарту тоже закрывает карту.</p>
        </div>
      </div>

      <div id="end-screen" className="overlay is-hidden">
        <div className="end-card panel">
          <h2 id="end-title">Рассвет</h2>
          <p id="end-copy" className="end-copy" />
          <div className="btn-row">
            <button id="retry-btn" type="button" className="btn-primary">
              Ещё смена
            </button>
          </div>
        </div>
      </div>

      <div id="start-screen" className="overlay">
        <div className="start-card panel">
          <h1 className="logo">Кейс на районе</h1>
          <p className="tagline">
            Кекс просыпается после чужой вечеринки. На пейджере — дядя Коля, пропавший кейс и
            рассвет, который лучше встретить в лесу, а не в багажнике.
          </p>
          <ul className="help">
            <li>
              <kbd>W</kbd> <kbd>A</kbd> <kbd>S</kbd> <kbd>D</kbd> или стик — ходьба и руль
            </li>
            <li>
              <kbd>E</kbd> / Войти — дверь, разговор, сесть в тачку
            </li>
            <li>
              <kbd>Пробел</kbd> — удар пешком, тормоз за рулём. Кнопка «Газ» жмёт педаль.
            </li>
            <li>Миникарта открывает весь район: кварталы, реку и лес за мостом.</li>
          </ul>
          <div className="btn-row">
            <button id="start-btn" type="button" className="btn-primary">
              Start
            </button>
            <button id="continue-btn" type="button" className="btn-ghost" disabled>
              Продолжить
            </button>
          </div>
          <p className="fine">Новая игра. Прогресс миссии пишется сам — кнопка «Продолжить» подхватит смену.</p>
        </div>
      </div>
    </div>
  );
}
