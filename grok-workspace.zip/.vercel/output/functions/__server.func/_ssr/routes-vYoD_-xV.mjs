import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Heart, i as Map, n as Volume2, t as VolumeX } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-vYoD_-xV.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var TW = 16;
var COLS = 86;
var ROWS = 72;
var SAVE_KEY = "keis-na-raione-v1";
var T = {
	GRASS: 0,
	ROAD: 1,
	WALK: 2,
	ROOF: 3,
	WATER: 4,
	SAND: 5,
	FOREST: 6,
	DIRT: 7,
	BRIDGE: 8,
	WALL: 9,
	WOOD: 10,
	TILE: 11,
	CONC: 12,
	CHECK: 13,
	DARK: 14,
	PARK: 15,
	NEON: 16
};
var ROOMS = {
	apt: {
		cols: 22,
		rows: 15,
		sx: 176,
		sy: 158,
		ex: 176,
		ey: 226
	},
	diner: {
		cols: 20,
		rows: 14,
		sx: 160,
		sy: 176,
		ex: 160,
		ey: 208
	},
	club: {
		cols: 22,
		rows: 16,
		sx: 176,
		sy: 200,
		ex: 176,
		ey: 240
	},
	ware: {
		cols: 24,
		rows: 16,
		sx: 192,
		sy: 200,
		ex: 192,
		ey: 240
	}
};
var CASE_POS = {
	x: 280,
	y: 748
};
var EXIT_POS = {
	x: 824,
	y: 1080
};
var RITA_PRICE = 80;
function hash(seed) {
	let a = seed >>> 0;
	return () => {
		a = a + 1831565813 | 0;
		let t = Math.imul(a ^ a >>> 15, 1 | a);
		t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
		return ((t ^ t >>> 14) >>> 0) / 4294967296;
	};
}
function clamp(v, a, b) {
	return Math.max(a, Math.min(b, v));
}
function angDiff(a, b) {
	return Math.atan2(Math.sin(b - a), Math.cos(b - a));
}
function isSolid(tile) {
	return tile === T.ROOF || tile === T.WATER || tile === T.WALL;
}
function ctx2d(canvas) {
	const context = canvas.getContext("2d");
	if (!context) throw new Error("2d");
	return context;
}
function mountGame(root) {
	const canvas = must("#game-canvas");
	const ctx = ctx2d(canvas);
	const hud = must("#hud");
	const startScreen = must("#start-screen");
	const endScreen = must("#end-screen");
	const missionKicker = must("#mission-kicker");
	const missionText = must("#mission-text");
	const moneyVal = must("#money-val");
	const hpFill = must("#hp-fill");
	const hpNum = must("#hp-num");
	const hintEl = must("#hint");
	const bannerEl = must("#banner");
	const mini = must("#minimap");
	const big = must("#bigmap");
	const mapOverlay = must("#map-overlay");
	const dialogEl = must("#dialog");
	const portrait = must("#portrait");
	const dlgName = must("#dlg-name");
	const dlgText = must("#dlg-text");
	const fadeEl = must("#fade");
	const touchEl = must("#touch-ui");
	const joyEl = must("#joy");
	const knob = must("#joy-knob");
	const btnAct = must("#btn-act");
	const btnAtk = must("#btn-atk");
	const btnBrake = must("#btn-brake");
	const btnHorn = must("#btn-horn");
	const soundBtn = must("#sound-btn");
	const continueBtn = must("#continue-btn");
	const endTitle = must("#end-title");
	const endCopy = must("#end-copy");
	const pctx = ctx2d(portrait);
	const mctx = ctx2d(mini);
	const bctx = ctx2d(big);
	const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
	const keys = /* @__PURE__ */ new Set();
	const joy = {
		x: 0,
		y: 0
	};
	let joyId = null;
	const joyOrigin = {
		x: 0,
		y: 0
	};
	let actionEdge = false;
	let atkEdge = false;
	let atkHeld = false;
	let brakeHeld = false;
	let hornEdge = false;
	let mouseDown = false;
	let prevE = false;
	let prevH = false;
	let steerForced = false;
	let forcedSteer = 0;
	let touchMode = "auto";
	let muted = false;
	let mode = "title";
	let world = "city";
	let time = 0;
	let playTime = 0;
	let saveAcc = 0;
	let shake = 0;
	let hitStop = 0;
	let bannerT = 0;
	let crashCd = 0;
	let sauceAt = 0;
	let punkHit = false;
	let pendingEnd = false;
	let mapOpen = false;
	let fade = 0;
	let fadePhase = "none";
	let fadeJob = null;
	let viewW = 384;
	let viewH = 216;
	let camX = 280;
	let camY = 80;
	let driven = null;
	const flags = blankFlags();
	let money = 30;
	const player = {
		x: 480,
		y: 200,
		yaw: 0,
		vx: 0,
		vy: 0,
		hp: 100,
		iframes: 0,
		swing: 0,
		stepAcc: 0,
		r: 6
	};
	const cp = {
		world: "apt",
		x: 176,
		y: 158
	};
	const maps = {};
	const buildings = [];
	const portals = [];
	const props = [];
	const trees = [];
	const decals = [];
	const cars = [];
	const punks = [];
	const npcs = [];
	const particles = [];
	const floats = [];
	let dialog = null;
	const tileCanvas = buildTileSprites();
	const waterB = tileCanvas[T.WATER + 20];
	const treeSprites = buildTreeSprites();
	buildWorld();
	const miniStatic = renderMiniStatic();
	let audioCtx = null;
	let master = null;
	let sfxBus = null;
	let eng = null;
	let engGain = null;
	let noiseBuf = null;
	const ac = new AbortController();
	const signal = ac.signal;
	function must(sel) {
		const el = root.querySelector(sel);
		if (!el) throw new Error(sel);
		return el;
	}
	function unlock() {
		const Ctor = window.AudioContext || window.webkitAudioContext;
		if (!Ctor) return;
		if (!audioCtx) {
			audioCtx = new Ctor();
			master = audioCtx.createGain();
			sfxBus = audioCtx.createGain();
			master.gain.value = .85;
			sfxBus.connect(master);
			master.connect(audioCtx.destination);
			const osc = audioCtx.createOscillator();
			const filter = audioCtx.createBiquadFilter();
			filter.type = "lowpass";
			filter.frequency.value = 480;
			engGain = audioCtx.createGain();
			engGain.gain.value = 0;
			osc.type = "sawtooth";
			osc.frequency.value = 70;
			osc.connect(filter);
			filter.connect(engGain);
			engGain.connect(sfxBus);
			osc.start();
			eng = osc;
		}
		if (audioCtx.state === "suspended") audioCtx.resume();
	}
	function tone(freq, dur, type, gainV) {
		if (!audioCtx || !sfxBus || muted) return;
		const o = audioCtx.createOscillator();
		const g = audioCtx.createGain();
		o.type = type;
		o.frequency.value = freq;
		g.gain.setValueAtTime(gainV, audioCtx.currentTime);
		g.gain.exponentialRampToValueAtTime(.001, audioCtx.currentTime + dur);
		o.connect(g);
		g.connect(sfxBus);
		o.start();
		o.stop(audioCtx.currentTime + dur);
		o.onended = () => {
			o.disconnect();
			g.disconnect();
		};
	}
	function noise(dur, gainV, freq) {
		if (!audioCtx || !sfxBus || muted) return;
		if (!noiseBuf) {
			noiseBuf = audioCtx.createBuffer(1, Math.floor(audioCtx.sampleRate * .2), audioCtx.sampleRate);
			const data = noiseBuf.getChannelData(0);
			for (let i = 0; i < data.length; i++) data[i] = Math.random() * 2 - 1;
		}
		const src = audioCtx.createBufferSource();
		src.buffer = noiseBuf;
		const g = audioCtx.createGain();
		const f = audioCtx.createBiquadFilter();
		f.type = "bandpass";
		f.frequency.value = freq;
		g.gain.setValueAtTime(gainV, audioCtx.currentTime);
		g.gain.exponentialRampToValueAtTime(.001, audioCtx.currentTime + dur);
		src.connect(f);
		f.connect(g);
		g.connect(sfxBus);
		src.start();
		src.stop(audioCtx.currentTime + dur);
		src.onended = () => {
			src.disconnect();
			f.disconnect();
			g.disconnect();
		};
	}
	const sfx = {
		step: () => {
			noise(.05, .07, 160 + Math.random() * 80);
		},
		punch: () => {
			noise(.08, .16, 280);
			tone(80 + Math.random() * 40, .07, "square", .05);
		},
		horn: () => {
			tone(446, .16, "square", .05);
			tone(560, .16, "square", .03);
		},
		blip: () => tone(760 + Math.random() * 280, .045, "square", .04),
		coin: () => {
			tone(880, .06, "square", .05);
			tone(1320, .09, "square", .04);
		},
		crash: () => {
			if (crashCd > 0) return;
			crashCd = .28;
			noise(.14, .16, 180);
		},
		hurt: () => tone(160, .12, "sawtooth", .06),
		pager: () => {
			tone(980, .06, "square", .05);
			tone(980, .06, "square", .05);
		}
	};
	function showBanner(text) {
		bannerEl.textContent = text;
		bannerEl.classList.remove("is-hidden");
		bannerT = 2.3;
	}
	function say(lines) {
		dialog = {
			lines,
			i: 0
		};
		renderDialog();
	}
	function advance() {
		if (!dialog) return;
		dialog.i += 1;
		if (dialog.i >= dialog.lines.length) {
			dialog = null;
			renderDialog();
			if (pendingEnd) {
				pendingEnd = false;
				showEnd();
			}
		} else renderDialog();
	}
	function renderDialog() {
		if (!dialog) {
			dialogEl.classList.add("is-hidden");
			return;
		}
		const line = dialog.lines[dialog.i];
		if (!line) return;
		dialogEl.classList.remove("is-hidden");
		dlgName.textContent = line.name;
		dlgText.textContent = line.text;
		drawPortrait(line.who);
		sfx.blip();
	}
	function goal() {
		if (!flags.pager) return "pager";
		if (!flags.left) return "leave";
		if (!flags.case && !flags.lyokha) return "lyokha";
		if (!flags.case) return "case";
		if (!flags.rita) return "rita";
		if (!flags.safe) return "safe";
		if (!flags.won) return "escape";
		return "done";
	}
	function goalCopy(g) {
		switch (g) {
			case "pager": return {
				n: 1,
				text: "Возьми пейджер с тумбочки"
			};
			case "leave": return {
				n: 1,
				text: "Выйди из квартиры на район"
			};
			case "lyokha": return {
				n: 2,
				text: "Дойди до «Жирного карпа» и поговори с Лёхой"
			};
			case "case": return {
				n: 3,
				text: "Забери кейс у хулиганов в роще у реки"
			};
			case "rita": return {
				n: 4,
				text: "Заплати Рите в «Неоне» $80 и забери первую половину кода"
			};
			case "safe": return {
				n: 5,
				text: "Открой сейф на складе. Код 4107"
			};
			case "escape": return {
				n: 6,
				text: "Через мост в лес, до просеки. Красные уже едут"
			};
			default: return {
				n: 6,
				text: "Рассвет. Смена закрыта"
			};
		}
	}
	function guide() {
		const spot = goalSpot(goal());
		if (!spot) return null;
		if (spot.world === world) return spot;
		if (world !== "city") {
			const exit = portals.find((p) => p.world === world && p.to === "city");
			return exit ? {
				x: exit.x,
				y: exit.y
			} : null;
		}
		const door = portals.find((p) => p.world === "city" && p.to === spot.world);
		return door ? {
			x: door.x,
			y: door.y
		} : null;
	}
	function goalSpot(g) {
		if (g === "pager") return {
			world: "apt",
			x: 78,
			y: 86
		};
		if (g === "leave") return {
			world: "apt",
			x: ROOMS.apt.ex,
			y: ROOMS.apt.ey
		};
		if (g === "lyokha") return world === "diner" ? {
			world: "diner",
			x: 160,
			y: 118
		} : {
			world: "city",
			x: doorOf("diner").x,
			y: doorOf("diner").y
		};
		if (g === "case") {
			if (!punks.some((p) => p.alive)) return {
				world: "city",
				x: CASE_POS.x,
				y: CASE_POS.y
			};
			const p0 = punks.find((p) => p.alive) ?? punks[0];
			return p0 ? {
				world: "city",
				x: p0.x,
				y: p0.y
			} : {
				world: "city",
				x: CASE_POS.x,
				y: CASE_POS.y
			};
		}
		if (g === "rita") return world === "club" ? {
			world: "club",
			x: 220,
			y: 96
		} : {
			world: "city",
			x: doorOf("club").x,
			y: doorOf("club").y
		};
		if (g === "safe") return world === "ware" ? {
			world: "ware",
			x: 300,
			y: 72
		} : {
			world: "city",
			x: doorOf("ware").x,
			y: doorOf("ware").y
		};
		if (g === "escape") return {
			world: "city",
			x: EXIT_POS.x,
			y: EXIT_POS.y
		};
		return null;
	}
	function doorOf(id) {
		return portals.find((d) => d.world === "city" && d.to === id) ?? {
			x: 400,
			y: 200
		};
	}
	function fadeTo(job) {
		if (fadePhase !== "none") return;
		fadePhase = "in";
		fadeJob = job;
	}
	function rememberCheckpoint() {
		if (driven) return;
		cp.world = world;
		cp.x = player.x;
		cp.y = player.y;
	}
	function save() {
		const data = {
			v: 1,
			flags: { ...flags },
			money,
			hp: player.hp,
			world,
			x: player.x,
			y: player.y,
			yaw: driven ? driven.yaw : player.yaw,
			cp: { ...cp },
			punks: punks.map((p) => ({
				alive: p.alive,
				hp: p.hp,
				x: p.x,
				y: p.y
			})),
			cars: cars.filter((c) => c.kind !== "chase").map((c) => ({
				id: c.id,
				x: c.x,
				y: c.y,
				yaw: c.yaw,
				speed: c.speed,
				ai: c.ai,
				tamed: c.tamed
			})),
			time: playTime,
			punkHit,
			inCar: driven?.id ?? null,
			muted
		};
		try {
			localStorage.setItem(SAVE_KEY, JSON.stringify(data));
		} catch {}
		continueBtn.disabled = false;
	}
	function load() {
		const raw = localStorage.getItem(SAVE_KEY);
		if (!raw) return false;
		try {
			const data = JSON.parse(raw);
			if (data.v !== 1 || !data.flags) return false;
			Object.assign(flags, blankFlags(), data.flags);
			money = data.money ?? 30;
			player.hp = data.hp ?? 100;
			world = data.world ?? "apt";
			player.x = data.x ?? ROOMS.apt.sx;
			player.y = data.y ?? ROOMS.apt.sy;
			player.yaw = data.yaw ?? 0;
			player.vx = 0;
			player.vy = 0;
			if (data.cp) {
				cp.world = data.cp.world;
				cp.x = data.cp.x;
				cp.y = data.cp.y;
			}
			punkHit = Boolean(data.punkHit);
			playTime = data.time ?? 0;
			muted = Boolean(data.muted);
			soundBtn.classList.toggle("is-muted", muted);
			if (data.punks) data.punks.forEach((p, i) => {
				const dst = punks[i];
				if (!dst) return;
				dst.alive = p.alive;
				dst.hp = p.hp;
				dst.x = p.x;
				dst.y = p.y;
			});
			clearChasers();
			for (const saved of data.cars ?? []) {
				const car = cars.find((c) => c.id === saved.id);
				if (!car) continue;
				car.x = saved.x;
				car.y = saved.y;
				car.yaw = saved.yaw;
				car.speed = saved.speed;
				car.ai = saved.ai;
				car.tamed = saved.tamed;
				car.occupied = false;
			}
			driven = null;
			if (data.inCar) {
				const car = cars.find((c) => c.id === data.inCar && c.alive);
				if (car) {
					driven = car;
					car.occupied = true;
					player.x = car.x;
					player.y = car.y;
				}
			}
			if (flags.safe && !flags.won) spawnChasers();
			return true;
		} catch {
			return false;
		}
	}
	function blankFlags() {
		return {
			pager: false,
			left: false,
			lyokha: false,
			case: false,
			cash: false,
			rita: false,
			safe: false,
			won: false
		};
	}
	function resetPunks() {
		const spots = [
			[264, 728],
			[352, 736],
			[196, 712]
		];
		punks.length = 0;
		for (const [x, y] of spots) punks.push({
			x: x ?? 0,
			y: y ?? 0,
			yaw: 0,
			hp: 48,
			alive: true,
			cd: 0,
			hurt: 0,
			wander: Math.random() * 2
		});
	}
	function resetCars() {
		clearChasers();
		for (const car of cars) {
			car.x = car.homeX;
			car.y = car.homeY;
			car.yaw = car.homeYaw;
			car.speed = 0;
			car.side = 0;
			car.occupied = false;
			car.tamed = false;
			car.stuck = 0;
			car.alive = true;
			car.ai = car.kind === "taxi" ? "loop" : "parked";
			car.loopDir = 1;
		}
		driven = null;
	}
	function clearChasers() {
		for (let i = cars.length - 1; i >= 0; i--) if (cars[i]?.kind === "chase") cars.splice(i, 1);
	}
	function spawnChasers() {
		if (cars.some((c) => c.kind === "chase")) return;
		makeCar("chase-a", 832, 240, Math.PI, "#c81e3a", "chase", "chase");
		makeCar("chase-b", 860, 420, Math.PI, "#9d1630", "chase", "chase");
	}
	function makeCar(id, x, y, yaw, color, kind, ai) {
		const car = {
			id,
			x,
			y,
			yaw,
			speed: 0,
			side: 0,
			color,
			kind,
			ai,
			loopDir: 1,
			homeX: x,
			homeY: y,
			homeYaw: yaw,
			r: 9,
			occupied: false,
			alive: true,
			stuck: 0,
			tamed: false
		};
		cars.push(car);
		return car;
	}
	function newGame() {
		Object.assign(flags, blankFlags());
		money = 30;
		player.hp = 100;
		player.iframes = 0;
		player.swing = 0;
		player.yaw = 0;
		player.vx = 0;
		player.vy = 0;
		world = "apt";
		player.x = ROOMS.apt.sx;
		player.y = ROOMS.apt.sy;
		cp.world = "apt";
		cp.x = player.x;
		cp.y = player.y;
		punkHit = false;
		pendingEnd = false;
		playTime = 0;
		sauceAt = 0;
		dialog = null;
		renderDialog();
		resetPunks();
		resetCars();
		particles.length = 0;
		floats.length = 0;
		beginPlay();
		showBanner("Пейджер на тумбочке. Район ещё не в курсе, что ты встал.");
		save();
	}
	function beginPlay() {
		mode = "play";
		startScreen.classList.add("is-hidden");
		endScreen.classList.add("is-hidden");
		hud.classList.remove("is-hidden");
		mapOpen = false;
		mapOverlay.classList.add("is-hidden");
		syncTouch();
		syncVehicleUi();
		camX = player.x - viewW / 2;
		camY = player.y - viewH / 2;
	}
	function showEnd() {
		mode = "end";
		const m = Math.floor(playTime / 60);
		const s = Math.floor(playTime % 60);
		endTitle.textContent = "Рассвет";
		endCopy.textContent = `Кейс у Коли, сосны у тебя. В кармане $${money}. Смена заняла ${m}:${s.toString().padStart(2, "0")}. Красные машины остались разговаривать с мостом.`;
		endScreen.classList.remove("is-hidden");
		dialog = null;
		renderDialog();
		save();
	}
	function hurt(amount) {
		if (player.iframes > 0 || mode !== "play" || fadePhase !== "none") return;
		player.hp = Math.max(0, player.hp - amount);
		player.iframes = .7;
		shake = Math.min(1, shake + .5);
		sfx.hurt();
		burst(player.x, player.y, "#ff5a7a", 6);
		if (player.hp <= 0) die();
	}
	function die() {
		if (fadePhase !== "none") return;
		player.hp = 0;
		fadeTo(() => {
			if (driven) {
				driven.occupied = false;
				driven.speed = 0;
				if (driven.kind === "taxi") driven.ai = "loop";
				if (driven.kind === "chase") driven.ai = "chase";
				driven = null;
			}
			world = cp.world;
			player.x = cp.x;
			player.y = cp.y;
			player.vx = 0;
			player.vy = 0;
			player.hp = 100;
			player.iframes = 1.3;
			syncVehicleUi();
			showBanner("Это не считается. Вставай красивее.");
			save();
		});
	}
	function punch() {
		player.swing = .28;
		hitStop = reduce ? 0 : .028;
		sfx.punch();
		const fx = -Math.sin(player.yaw);
		const fy = -Math.cos(player.yaw);
		const hx = player.x + fx * 14;
		const hy = player.y + fy * 14;
		let hit = false;
		if (world === "city") for (const punk of punks) {
			if (!punk.alive) continue;
			const d = Math.hypot(punk.x - hx, punk.y - hy);
			const d2 = Math.hypot(punk.x - player.x, punk.y - player.y);
			if (d < 16 || d2 < 20) {
				damagePunk(punk, 16, fx, fy);
				hit = true;
			}
		}
		if (hit) shake = Math.min(1, shake + .35);
	}
	function damagePunk(punk, dmg, fx, fy) {
		punk.hp -= dmg;
		punk.hurt = .12;
		punkHit = true;
		burst(punk.x, punk.y, "#e23b3b", 10);
		decals.push({
			world: "city",
			x: punk.x,
			y: punk.y,
			k: "blood",
			a: Math.random()
		});
		if (decals.length > 220) decals.splice(40, 1);
		floatText(punk.x, punk.y - 10, `-${dmg}`, "#ffe14a");
		punk.x += fx * 8;
		punk.y += fy * 8;
		if (punk.hp <= 0) {
			punk.alive = false;
			money += 40;
			sfx.coin();
			floatText(punk.x, punk.y - 18, "+$40", "#9dff6a");
			if (punks.every((p) => !p.alive) && !flags.case) showBanner("Кейс на траве. Бумаги не кусаются — в отличие от куртки.");
		}
	}
	function burst(x, y, color, n) {
		for (let i = 0; i < n; i++) {
			let p = particles.find((q) => q.life <= 0);
			if (!p) {
				if (particles.length > 140) p = particles[i % particles.length];
				else {
					p = {
						x: 0,
						y: 0,
						vx: 0,
						vy: 0,
						life: 0,
						max: 1,
						color,
						size: 2
					};
					particles.push(p);
				}
			}
			if (!p) continue;
			const a = Math.random() * Math.PI * 2;
			const s = 20 + Math.random() * 70;
			p.x = x;
			p.y = y;
			p.vx = Math.cos(a) * s;
			p.vy = Math.sin(a) * s;
			p.life = .25 + Math.random() * .25;
			p.max = p.life;
			p.color = color;
			p.size = 2 + Math.random() * 2 | 0;
		}
	}
	function floatText(x, y, text, color) {
		floats.push({
			x,
			y,
			text,
			life: .7,
			color
		});
		if (floats.length > 24) floats.shift();
	}
	function usePortal(p) {
		if (driven) {
			showBanner("Сначала выйди из машины. Двери не резиновые.");
			return;
		}
		if (p.world === "apt" && p.to === "city" && !flags.pager) {
			showBanner("Пейджер ещё орёт. Не оставляй Колю на голосовой.");
			return;
		}
		fadeTo(() => {
			const from = p.world;
			world = p.to;
			player.x = p.sx;
			player.y = p.sy;
			player.vx = 0;
			player.vy = 0;
			if (from === "apt" && world === "city" && !flags.left) {
				flags.left = true;
				showBanner("Район. Яркий, шумный и слегка незаконный.");
			}
			rememberCheckpoint();
			save();
		});
	}
	function enterCar(car) {
		if (Math.abs(car.speed) > 140) {
			showBanner("Она ещё летит. Подожди, пока колёса вспомнят асфальт.");
			return;
		}
		driven = car;
		car.occupied = true;
		car.speed *= .6;
		if (car.kind === "chase") car.tamed = true;
		player.x = car.x;
		player.y = car.y;
		player.yaw = car.yaw;
		syncVehicleUi();
		showBanner(car.kind === "taxi" ? "Шашечки свои, маршрут чужой." : "Ключи в замке. Район доверчивый.");
	}
	function leaveCar() {
		if (!driven) return;
		if (Math.abs(driven.speed) > 45) {
			showBanner("Притормози. Выходить на ходу — это уже другой жанр.");
			return;
		}
		const car = driven;
		const rx = Math.cos(car.yaw);
		const ry = -Math.sin(car.yaw);
		const fx = -Math.sin(car.yaw);
		const fy = -Math.cos(car.yaw);
		const spots = [
			{
				x: car.x + rx * 16,
				y: car.y + ry * 16
			},
			{
				x: car.x - rx * 16,
				y: car.y - ry * 16
			},
			{
				x: car.x - fx * 18,
				y: car.y - fy * 18
			}
		];
		let placed = false;
		for (const s of spots) if (!resolve(s.x, s.y, player.r, "city", true, car).hit) {
			player.x = s.x;
			player.y = s.y;
			placed = true;
			break;
		}
		if (!placed) {
			player.x = spots[0]?.x ?? car.x;
			player.y = spots[0]?.y ?? car.y;
		}
		player.yaw = car.yaw;
		car.occupied = false;
		car.speed = 0;
		if (car.kind === "taxi" && !car.tamed) car.ai = "loop";
		driven = null;
		syncVehicleUi();
	}
	function syncVehicleUi() {
		const inCar = Boolean(driven);
		btnBrake.classList.toggle("is-hidden", !inCar);
		btnHorn.classList.toggle("is-hidden", !inCar);
		btnAtk.textContent = inCar ? "Газ" : "Удар";
		btnAct.textContent = inCar ? "Выйти" : "Войти";
	}
	function findBest() {
		if (mode !== "play" || dialog) return null;
		const acts = [];
		const px = player.x;
		const py = player.y;
		if (driven) {
			acts.push({
				d: 0,
				hint: Math.abs(driven.speed) > 45 ? "Притормози, чтобы выйти" : "E — выйти из машины",
				use: () => leaveCar()
			});
			return acts[0] ?? null;
		}
		for (const p of portals) {
			if (p.world !== world) continue;
			const d = Math.hypot(p.x - px, p.y - py);
			if (d < 20) acts.push({
				d,
				hint: p.hint,
				use: () => usePortal(p)
			});
		}
		for (const car of cars) {
			if (!car.alive || car.occupied) continue;
			if (world !== "city") continue;
			const d = Math.hypot(car.x - px, car.y - py);
			if (d < 24) acts.push({
				d,
				hint: "E — сесть за руль",
				use: () => enterCar(car)
			});
		}
		for (const npc of npcs) {
			if (npc.world !== world) continue;
			const d = Math.hypot(npc.x - px, npc.y - py);
			if (d < 28) acts.push({
				d,
				hint: `E — говорить: ${npc.name}`,
				use: () => talkNpc(npc)
			});
		}
		if (world === "city") {
			for (const punk of punks) {
				if (!punk.alive) continue;
				const d = Math.hypot(punk.x - px, punk.y - py);
				if (d < 24) acts.push({
					d,
					hint: "E — перекинуться парой ласковых",
					use: () => talkPunk()
				});
			}
			if (!flags.case && punks.every((p) => !p.alive)) {
				const d = Math.hypot(CASE_POS.x - px, CASE_POS.y - py);
				if (d < 24) acts.push({
					d,
					hint: "E — поднять кейс",
					use: () => takeCase()
				});
			}
			if (flags.safe && !flags.won) {
				const d = Math.hypot(EXIT_POS.x - px, EXIT_POS.y - py);
				if (d < 30) acts.push({
					d,
					hint: "Просека. Можно просто дойти.",
					use: () => checkEscape()
				});
			}
		}
		if (world === "apt" && !flags.pager) {
			const d = Math.hypot(78 - px, 86 - py);
			if (d < 26) acts.push({
				d,
				hint: "E — прочитать пейджер",
				use: () => readPager()
			});
		}
		if (world === "apt" && !flags.cash) {
			const d = Math.hypot(250 - px, 156 - py);
			if (d < 24) acts.push({
				d,
				hint: "E — шарить под диваном",
				use: () => takeCash()
			});
		}
		if (world === "apt") {
			const d = Math.hypot(210 - px, 112 - py);
			if (d < 22) acts.push({
				d,
				hint: "E — крутануть радио",
				use: () => radio()
			});
		}
		if (world === "diner") {
			const d = Math.hypot(46 - px, 160 - py);
			if (d < 22) acts.push({
				d,
				hint: "E — соус дня, лечит гордость",
				use: () => drinkSauce()
			});
			const m = Math.hypot(40 - px, 40 - py);
			if (m < 22) acts.push({
				d: m,
				hint: "E — меню",
				use: () => menu()
			});
		}
		if (world === "ware") {
			const d = Math.hypot(300 - px, 72 - py);
			if (d < 28) acts.push({
				d,
				hint: "E — сейф",
				use: () => useSafe()
			});
			const c = Math.hypot(78 - px, 90 - py);
			if (c < 24) acts.push({
				d: c,
				hint: "E — ящик",
				use: () => crateLine()
			});
		}
		if (!acts.length) return null;
		acts.sort((a, b) => a.d - b.d);
		return acts[0] ?? null;
	}
	function readPager() {
		flags.pager = true;
		sfx.pager();
		say([
			{
				who: "keks",
				name: "Кекс",
				text: "Голова гудит так, будто в ней минивэн сдаёт назад."
			},
			{
				who: "pager",
				name: "Пейджер",
				text: "ДЯДЯ КОЛЯ: КЕКС. КЕЙС С НАКЛАДНЫМИ УКРАЛИ. БЕЗ БУМАГ СКЛАД — ПРОСТО САРАЙ. ЛЁХА В «ЖИРНОМ КАРПЕ». ДО РАССВЕТА. НЕ ОРИ В ЭФИР."
			},
			{
				who: "keks",
				name: "Кекс",
				text: "«Жирный карп». Самое приличное место района, если слово «прилично» ничего не значит."
			}
		]);
		rememberCheckpoint();
		save();
	}
	function takeCash() {
		flags.cash = true;
		money += 50;
		sfx.coin();
		floatText(player.x, player.y - 12, "+$50", "#9dff6a");
		say([{
			who: "keks",
			name: "Кекс",
			text: "Под диваном полтинник и чья-то серёжка. Серёжку оставлю. Деньги — нет. Это называется уборка."
		}]);
		save();
	}
	function radio() {
		say([{
			who: "pager",
			name: "Радио",
			text: "…и помните: если за вами красная машина, это не плейлист. Это четверг."
		}, {
			who: "keks",
			name: "Кекс",
			text: "Полезная частота. Жаль, не варит кофе."
		}]);
	}
	function talkNpc(npc) {
		if (npc.id === "lyokha") {
			if (!flags.lyokha) {
				flags.lyokha = true;
				say([
					{
						who: "lyokha",
						name: "Лёха",
						text: "О, дышит. Коля уже орёт — голуби с этого района эмигрировали."
					},
					{
						who: "lyokha",
						name: "Лёха",
						text: "Кейс забрали трое в зелёных куртках. Тусуют в роще у реки, прямо перед мостом. Пахнет дешёвым одеколоном и плохими решениями."
					},
					{
						who: "lyokha",
						name: "Лёха",
						text: "Тачки тут не запирают. Это не доверие, это лень. Кулаки у тебя громче пейджера — пользуйся точечно."
					}
				]);
				rememberCheckpoint();
				save();
			} else say([{
				who: "lyokha",
				name: "Лёха",
				text: "Роща, зелёные куртки, не геройствуй. Ладно, геройствуй, но по делу. Суп сегодня лучше не надо."
			}]);
			return;
		}
		if (npc.id === "rita") {
			if (flags.rita) {
				say([{
					who: "rita",
					name: "Рита",
					text: "Сорок один. Не потеряй, как теряешь ключи, людей и тему разговора."
				}]);
				return;
			}
			if (money < RITA_PRICE) {
				say([{
					who: "rita",
					name: "Рита",
					text: "Восемьдесят баксов — и я вспомню цифры. «Потом» не котируется с той ночи, когда ты попросил просто подержать сумку."
				}]);
				return;
			}
			money -= RITA_PRICE;
			flags.rita = true;
			sfx.coin();
			say([{
				who: "rita",
				name: "Рита",
				text: `Сорок один. ${flags.case ? "Вместе с бумажкой из кейса это 4107. После этого мы квиты. Почти." : "Вторая половина в том кейсе, из-за которого Коля не спит. Вместе будет 4107."}`
			}, {
				who: "keks",
				name: "Кекс",
				text: "«Почти» — твоё любимое слово. Сейф на складе подождёт ровно до того, как я дойду."
			}]);
			rememberCheckpoint();
			save();
			return;
		}
		say([{
			who: "club",
			name: "Тусовщик",
			text: "Бас сегодня злой, пол липкий, а ты подозрительно вертикальный. Не свети этим."
		}]);
	}
	function talkPunk() {
		const hot = goal() === "case" || punkHit;
		say([{
			who: "punk",
			name: "Хулиган",
			text: hot ? "Поздно базарить. Кейс наш, пока ты не убедишь нас в обратном кулаком или бампером." : "Иди мимо, кепка. Роща занята людьми с плохим вкусом и хорошим замахом."
		}]);
		if (hot) punkHit = true;
	}
	function takeCase() {
		if (flags.case) return;
		flags.case = true;
		say([{
			who: "keks",
			name: "Кекс",
			text: "Накладные, чек из шаурмы и записка: «КОД СЕЙФА ??07. ПЕРВАЯ ПОЛОВИНА У РИТЫ В НЕОНЕ. ОНА ВСЁ ЕЩЁ ЗЛИТСЯ»."
		}, {
			who: "keks",
			name: "Кекс",
			text: "К чужим документам прилагаются чужие отношения. Классический комплект."
		}]);
		rememberCheckpoint();
		save();
	}
	function drinkSauce() {
		if (time < sauceAt) {
			showBanner("Соус ещё злой. Дай ему минуту.");
			return;
		}
		player.hp = Math.min(100, player.hp + 35);
		sauceAt = time + 12;
		sfx.coin();
		showBanner("Соус дня. Гордость зажила на 35 пунктов.");
	}
	function menu() {
		say([{
			who: "lyokha",
			name: "Меню",
			text: "ЖИРНЫЙ КАРП. Суп дня: «что было». Комбо «не спрашивай» — три доллара и изжога в подарок."
		}]);
	}
	function crateLine() {
		say([{
			who: "keks",
			name: "Кекс",
			text: "Пустые ящики. В кино в таких сидит кто-то с битой. Тут — пыль и амбиции."
		}]);
	}
	function useSafe() {
		if (flags.safe) {
			say([{
				who: "keks",
				name: "Кекс",
				text: "Пусто. Ты уже совершил свой маленький экономический рост."
			}]);
			return;
		}
		if (!flags.rita || !flags.case) {
			say([{
				who: "keks",
				name: "Кекс",
				text: "Сейф молчит. Нужны обе половины: Рита знает начало, кейс — конец. Пока это просто очень уверенная тумбочка."
			}]);
			return;
		}
		flags.safe = true;
		money += 500;
		sfx.coin();
		floatText(player.x, player.y - 14, "+$500", "#9dff6a");
		spawnChasers();
		say([
			{
				who: "keks",
				name: "Кекс",
				text: "Четыре, один, ноль, семь. Щелчок. Пачка, ключи и стикер «не забудь утюг»."
			},
			{
				who: "pager",
				name: "Пейджер",
				text: "КОЛЯ: МОЛОДЕЦ. ТЕПЕРЬ ВАЛИ ЧЕРЕЗ МОСТ В ЛЕС, К СТАРОЙ ПРОСЕКЕ. ЗА ТОБОЙ КРАСНЫЕ. СВЕТОФОРОВ НЕТ."
			},
			{
				who: "keks",
				name: "Кекс",
				text: "Обожаю, когда план побега приходит уже после того, как я внутри склада."
			}
		]);
		rememberCheckpoint();
		save();
	}
	function checkEscape() {
		if (flags.won || !flags.safe || world !== "city") return;
		if (Math.hypot(player.x - EXIT_POS.x, player.y - EXIT_POS.y) > 34) return;
		flags.won = true;
		pendingEnd = true;
		say([{
			who: "keks",
			name: "Кекс",
			text: "Сосны, река позади и ни одного пейджера в руке. На сегодня я честный человек. До следующего сигнала."
		}]);
		save();
	}
	function pushOut(cx, cy, r, L, T, R, B) {
		const qx = Math.max(L, Math.min(cx, R));
		const qy = Math.max(T, Math.min(cy, B));
		const dx = cx - qx;
		const dy = cy - qy;
		const d2 = dx * dx + dy * dy;
		if (d2 >= r * r) return null;
		if (d2 < 1e-6) {
			const dl = cx - L;
			const dr = R - cx;
			const dt = cy - T;
			const db = B - cy;
			const m = Math.min(dl, dr, dt, db);
			if (m === dl) return {
				x: L - r - .05,
				y: cy
			};
			if (m === dr) return {
				x: R + r + .05,
				y: cy
			};
			if (m === dt) return {
				x: cx,
				y: T - r - .05
			};
			return {
				x: cx,
				y: B + r + .05
			};
		}
		const d = Math.sqrt(d2);
		const pen = r - d + .05;
		return {
			x: cx + dx / d * pen,
			y: cy + dy / d * pen
		};
	}
	function resolve(x, y, r, mapId, withCars, self) {
		let hit = false;
		const map = maps[mapId];
		for (let pass = 0; pass < 2; pass++) {
			const x0 = Math.floor((x - r) / TW) - 1;
			const y0 = Math.floor((y - r) / TW) - 1;
			const x1 = Math.floor((x + r) / TW) + 1;
			const y1 = Math.floor((y + r) / TW) + 1;
			for (let ty = y0; ty <= y1; ty++) for (let tx = x0; tx <= x1; tx++) {
				let solid = true;
				if (tx >= 0 && ty >= 0 && tx < map.cols && ty < map.rows) solid = isSolid(map.tiles[ty * map.cols + tx] ?? T.WALL);
				if (!solid) continue;
				const pushed = pushOut(x, y, r, tx * TW, ty * TW, tx * TW + TW, ty * TW + TW);
				if (pushed) {
					x = pushed.x;
					y = pushed.y;
					hit = true;
				}
			}
			if (mapId === "city") for (const tree of trees) {
				const dx = x - tree.x;
				const dy = y - tree.y;
				const min = r + tree.r;
				const d2 = dx * dx + dy * dy;
				if (d2 >= min * min) continue;
				const d = Math.sqrt(d2) || .001;
				const pen = min - d;
				x += dx / d * pen;
				y += dy / d * pen;
				hit = true;
			}
			for (const prop of props) {
				if (!prop.solid || prop.world !== mapId) continue;
				if (prop.hideFlag && flags[prop.hideFlag]) continue;
				const pushed = pushOut(x, y, r, prop.x - prop.hw, prop.y - prop.hh, prop.x + prop.hw, prop.y + prop.hh);
				if (pushed) {
					x = pushed.x;
					y = pushed.y;
					hit = true;
				}
			}
			if (withCars && mapId === "city") for (const car of cars) {
				if (!car.alive || car === self) continue;
				const dx = x - car.x;
				const dy = y - car.y;
				const min = r + car.r;
				const d2 = dx * dx + dy * dy;
				if (d2 >= min * min) continue;
				const d = Math.sqrt(d2) || .001;
				const pen = min - d;
				x += dx / d * pen;
				y += dy / d * pen;
				hit = true;
			}
		}
		return {
			x,
			y,
			hit
		};
	}
	function moveBody(x, y, vx, vy, r, mapId, self, dt) {
		return resolve(x + vx * dt, y + vy * dt, r, mapId, true, self);
	}
	function updateCarMotion(car, dt) {
		const fx = -Math.sin(car.yaw);
		const fy = -Math.cos(car.yaw);
		const rx = Math.cos(car.yaw);
		const ry = -Math.sin(car.yaw);
		const vx = fx * car.speed + rx * car.side;
		const vy = fy * car.speed + ry * car.side;
		const before = Math.abs(car.speed);
		const res = moveBody(car.x, car.y, vx, vy, car.r, "city", car, dt);
		if (res.hit && before > 70) {
			car.speed *= .45;
			car.side *= .2;
			shake = Math.min(1, shake + (car.occupied ? .45 : .1));
			if (car.occupied) sfx.crash();
		}
		car.x = res.x;
		car.y = res.y;
	}
	function drivePlayer(dt) {
		if (!driven) return;
		let throttle = 0;
		let brake = 0;
		if (keys.has("KeyW") || keys.has("ArrowUp")) throttle = 1;
		if (joy.y < -.18) throttle = Math.max(throttle, -joy.y);
		if (atkHeld) throttle = 1;
		if (keys.has("KeyS") || keys.has("ArrowDown") || keys.has("Space") || brakeHeld || mouseDown && !root.classList.contains("show-touch")) brake = 1;
		if (joy.y > .2) brake = Math.max(brake, joy.y);
		if (brake > 0 && driven.speed >= 0) throttle = 0;
		let steer = 0;
		if (steerForced) steer = forcedSteer;
		else {
			if (keys.has("KeyA") || keys.has("ArrowLeft")) steer += 1;
			if (keys.has("KeyD") || keys.has("ArrowRight")) steer -= 1;
			steer -= joy.x;
			steer = clamp(steer, -1, 1);
		}
		const reverse = driven.speed >= 0 ? 1 : -1;
		const speedFactor = clamp(Math.abs(driven.speed) / 48, .42, 1);
		driven.yaw += steer * 2.6 * speedFactor * reverse * dt;
		if (throttle && !brake) driven.speed += (driven.speed < -8 ? 380 : 250) * dt;
		else if (brake) driven.speed -= (driven.speed > 16 ? 460 : 190) * dt;
		else {
			driven.speed *= Math.exp(-1.1 * dt);
			if (Math.abs(driven.speed) < 6) driven.speed = 0;
		}
		driven.speed = clamp(driven.speed, -100, 215);
		driven.side += steer * driven.speed * .7 * dt;
		driven.side *= Math.exp(-3.2 * dt);
		if (Math.abs(driven.side) > 36 && Math.abs(driven.speed) > 90 && Math.random() < .4) burst(driven.x, driven.y, "#d9d3c4", 1);
		updateCarMotion(driven, dt);
		player.x = driven.x;
		player.y = driven.y;
		player.yaw = driven.yaw;
		player.vx = -Math.sin(driven.yaw) * driven.speed;
		player.vy = -Math.cos(driven.yaw) * driven.speed;
	}
	function driveFoot(dt) {
		let ix = 0;
		let iy = 0;
		if (keys.has("KeyW") || keys.has("ArrowUp")) iy -= 1;
		if (keys.has("KeyS") || keys.has("ArrowDown")) iy += 1;
		if (keys.has("KeyA") || keys.has("ArrowLeft")) ix -= 1;
		if (keys.has("KeyD") || keys.has("ArrowRight")) ix += 1;
		ix += joy.x;
		iy += joy.y;
		const len = Math.hypot(ix, iy);
		if (len > 1) {
			ix /= len;
			iy /= len;
		} else if (len < .12) {
			ix = 0;
			iy = 0;
		}
		const speed = 96;
		player.vx = ix * speed;
		player.vy = iy * speed;
		if (ix !== 0 || iy !== 0) {
			const desired = Math.atan2(-player.vx, -player.vy);
			player.yaw += angDiff(player.yaw, desired) * Math.min(1, dt * 14);
			player.stepAcc += dt;
			if (player.stepAcc > .34) {
				player.stepAcc = 0;
				sfx.step();
			}
		} else player.stepAcc = 0;
		const res = moveBody(player.x, player.y, player.vx, player.vy, player.r, world, null, dt);
		if (res.hit) {
			player.vx *= .2;
			player.vy *= .2;
		}
		player.x = res.x;
		player.y = res.y;
	}
	function updatePunks(dt) {
		if (world !== "city") return;
		const aggressive = punkHit || goal() === "case";
		for (const punk of punks) {
			if (!punk.alive) continue;
			punk.cd = Math.max(0, punk.cd - dt);
			punk.hurt = Math.max(0, punk.hurt - dt);
			const dx = player.x - punk.x;
			const dy = player.y - punk.y;
			const d = Math.hypot(dx, dy) || .001;
			let vx = 0;
			let vy = 0;
			if (aggressive && !driven && d < 200) {
				const sp = 52;
				vx = dx / d * sp;
				vy = dy / d * sp;
				punk.yaw = Math.atan2(-vx, -vy);
				if (d < 16 && punk.cd <= 0 && !dialog) {
					punk.cd = .9;
					hurt(12);
					burst(player.x, player.y, "#ffd0dc", 4);
				}
			} else if (aggressive && driven && d < 230) {
				const sp = 34;
				vx = dx / d * sp;
				vy = dy / d * sp;
				punk.yaw = Math.atan2(-vx, -vy);
			} else {
				punk.wander += dt;
				if (punk.wander > 1.8) {
					punk.wander = 0;
					punk.yaw += (Math.random() - .5) * 2;
				}
				vx = -Math.sin(punk.yaw) * 16;
				vy = -Math.cos(punk.yaw) * 16;
			}
			for (const other of punks) {
				if (other === punk || !other.alive) continue;
				const ox = punk.x - other.x;
				const oy = punk.y - other.y;
				const od = Math.hypot(ox, oy) || .001;
				if (od < 14) {
					vx += ox / od * 30;
					vy += oy / od * 30;
				}
			}
			const res = moveBody(punk.x, punk.y, vx, vy, 6, "city", null, dt);
			punk.x = res.x;
			punk.y = res.y;
			if (driven && Math.abs(driven.speed) > 75) {
				if (Math.hypot(driven.x - punk.x, driven.y - punk.y) < 16 && punk.cd <= 0) {
					punk.cd = .4;
					damagePunk(punk, 48, -Math.sin(driven.yaw), -Math.cos(driven.yaw));
					shake = Math.min(1, shake + .4);
					sfx.crash();
				}
			}
		}
	}
	function updateTraffic(dt) {
		for (const car of cars) {
			if (!car.alive || car.occupied) continue;
			if (car.ai === "loop") {
				if (car.x > 1280) car.loopDir = -1;
				if (car.x < 96) car.loopDir = 1;
				const target = car.loopDir > 0 ? -Math.PI / 2 : Math.PI / 2;
				car.yaw += clamp(angDiff(car.yaw, target), -2.4 * dt, 2.4 * dt);
				let want = 125;
				if (world === "city" && !driven) {
					if (Math.hypot(car.x - player.x, car.y - player.y) < 34) want = 0;
				}
				car.speed += (want - car.speed) * Math.min(1, dt * 1.6);
				updateCarMotion(car, dt);
			} else if (car.ai === "chase" && !car.tamed && flags.safe && !flags.won) {
				let tx = player.x;
				let ty = player.y;
				if (world !== "city") {
					const door = portals.find((p) => p.world === "city" && p.to === world);
					if (door) {
						tx = door.x;
						ty = door.y + 28;
					}
				}
				const dx = tx - car.x;
				const dy = ty - car.y;
				const desired = Math.atan2(-dx, -dy);
				car.yaw += clamp(angDiff(car.yaw, desired), -2.15 * dt, 2.15 * dt);
				car.speed += (170 - car.speed) * Math.min(1, dt * 1.3);
				if (Math.abs(car.speed) < 14) car.stuck += dt;
				else car.stuck = 0;
				if (car.stuck > .75) {
					car.yaw += 1.5;
					car.speed = -80;
					car.stuck = 0;
				}
				updateCarMotion(car, dt);
				if (world === "city" && mode === "play" && !dialog) {
					if (Math.hypot(car.x - player.x, car.y - player.y) < 20 && Math.abs(car.speed) > 50) hurt(16);
				}
			}
		}
	}
	function update(dt) {
		time += dt;
		crashCd = Math.max(0, crashCd - dt);
		shake *= Math.exp(-3.4 * dt);
		if (bannerT > 0) {
			bannerT -= dt;
			if (bannerT <= 0) bannerEl.classList.add("is-hidden");
		}
		for (const p of particles) {
			if (p.life <= 0) continue;
			p.life -= dt;
			p.x += p.vx * dt;
			p.y += p.vy * dt;
			p.vy += 20 * dt;
		}
		for (const f of floats) {
			f.life -= dt;
			f.y -= 16 * dt;
		}
		if (fadePhase === "in") {
			fade = Math.min(1, fade + dt / .16);
			if (fade >= 1 && fadeJob) {
				const job = fadeJob;
				fadeJob = null;
				job();
				fadePhase = "out";
			}
		} else if (fadePhase === "out") {
			fade = Math.max(0, fade - dt / .2);
			if (fade <= 0) fadePhase = "none";
		}
		const eNow = keys.has("KeyE") || keys.has("Enter");
		const eEdge = eNow && !prevE || actionEdge;
		prevE = eNow;
		actionEdge = false;
		const hNow = keys.has("KeyH");
		const hEdge = hNow && !prevH || hornEdge;
		prevH = hNow;
		hornEdge = false;
		if (mode === "title") {
			updateTraffic(dt);
			atkEdge = false;
			return;
		}
		if (mode !== "play") {
			atkEdge = false;
			return;
		}
		playTime += dt;
		player.iframes = Math.max(0, player.iframes - dt);
		player.swing = Math.max(0, player.swing - dt);
		if (eng && engGain && audioCtx) {
			const v = driven && !muted ? Math.min(1, Math.abs(driven.speed) / 210) : 0;
			eng.frequency.setTargetAtTime(55 + (driven ? Math.abs(driven.speed) / 210 : 0) * 110, audioCtx.currentTime, .08);
			engGain.gain.setTargetAtTime(v * .1, audioCtx.currentTime, .06);
		}
		if (eEdge && fadePhase !== "in" && !mapOpen) {
			if (dialog) advance();
			else findBest()?.use();
		}
		if (hEdge && driven) sfx.horn();
		if (dialog || mapOpen || fadePhase === "in") {
			atkEdge = false;
			return;
		}
		if (driven) drivePlayer(dt);
		else {
			driveFoot(dt);
			if ((keys.has("Space") || atkHeld || atkEdge) && player.swing <= 0) punch();
		}
		atkEdge = false;
		updatePunks(dt);
		updateTraffic(dt);
		checkEscape();
		saveAcc += dt;
		if (saveAcc > 5) {
			saveAcc = 0;
			save();
		}
	}
	function updateCamera(dt) {
		const map = maps[world];
		const fx = -Math.sin(player.yaw);
		const fy = -Math.cos(player.yaw);
		const look = driven ? 26 : 12;
		let tx = player.x + fx * look - viewW / 2;
		let ty = player.y + fy * look - viewH / 2;
		if (mode === "title") {
			tx = 360 + Math.sin(time * .15) * 80;
			ty = 120 + Math.cos(time * .11) * 30;
		}
		const k = 1 - Math.exp(-7 * dt);
		camX += (tx - camX) * k;
		camY += (ty - camY) * k;
		const mw = map.cols * TW;
		const mh = map.rows * TW;
		camX = mw <= viewW ? (mw - viewW) / 2 : clamp(camX, 0, mw - viewW);
		camY = mh <= viewH ? (mh - viewH) / 2 : clamp(camY, 0, mh - viewH);
	}
	const dlY = [];
	const dlK = [];
	const dlI = [];
	const order = [];
	function render() {
		updateCamera(1 / 60);
		ctx.imageSmoothingEnabled = false;
		const mag = reduce ? 0 : shake * 7;
		const shx = Math.sin(time * 73) * mag | 0;
		const shy = Math.cos(time * 61) * mag | 0;
		ctx.setTransform(1, 0, 0, 1, 0, 0);
		ctx.fillStyle = "#1a1030";
		ctx.fillRect(0, 0, viewW, viewH);
		ctx.save();
		ctx.translate(shx - Math.round(camX), shy - Math.round(camY));
		const map = maps[world];
		const x0 = Math.max(0, Math.floor(camX / TW) - 1);
		const y0 = Math.max(0, Math.floor(camY / TW) - 1);
		const x1 = Math.min(map.cols - 1, Math.floor((camX + viewW) / TW) + 1);
		const y1 = Math.min(map.rows - 1, Math.floor((camY + viewH) / TW) + 1);
		const waterFrame = time * 3 | 1 ? (time * 3 | 0) % 2 : 0;
		for (let ty = y0; ty <= y1; ty++) for (let tx = x0; tx <= x1; tx++) {
			const tile = map.tiles[ty * map.cols + tx] ?? T.GRASS;
			const img = tile === T.WATER && waterFrame ? waterB : tileCanvas[tile];
			if (img) ctx.drawImage(img, tx * TW, ty * TW);
			if (tile === T.ROAD || tile === T.PARK || tile === T.BRIDGE || tile === T.DIRT) {
				ctx.fillStyle = "rgba(18,10,28,0.45)";
				const up = tileAt(map, tx, ty - 1);
				const dn = tileAt(map, tx, ty + 1);
				const lf = tileAt(map, tx - 1, ty);
				const rt = tileAt(map, tx + 1, ty);
				if (up === T.WALK || up === T.GRASS || up === T.SAND) ctx.fillRect(tx * TW, ty * TW, TW, 2);
				if (dn === T.WALK || dn === T.GRASS || dn === T.SAND) ctx.fillRect(tx * TW, ty * TW + TW - 2, TW, 2);
				if (lf === T.WALK || lf === T.GRASS) ctx.fillRect(tx * TW, ty * TW, 2, TW);
				if (rt === T.WALK || rt === T.GRASS) ctx.fillRect(tx * TW + TW - 2, ty * TW, 2, TW);
			}
		}
		for (const d of decals) {
			if (d.world !== world) continue;
			if (d.x < camX - 20 || d.y < camY - 20 || d.x > camX + viewW + 20 || d.y > camY + viewH + 20) continue;
			drawDecal(d);
		}
		let dn = 0;
		const add = (y, k, i) => {
			dlY[dn] = y;
			dlK[dn] = k;
			dlI[dn] = i;
			dn += 1;
		};
		if (world === "city") {
			for (let i = 0; i < buildings.length; i++) {
				const b = buildings[i];
				if (!b) continue;
				add((b.ty + b.th) * TW + 8, 0, i);
			}
			for (let i = 0; i < trees.length; i++) add(trees[i]?.y ?? 0, 1, i);
			for (let i = 0; i < cars.length; i++) if (cars[i]?.alive) add(cars[i]?.y ?? 0, 3, i);
			for (let i = 0; i < punks.length; i++) if (punks[i]?.alive) add(punks[i]?.y ?? 0, 4, i);
			if (!flags.case && punks.length && punks.every((p) => !p.alive)) add(CASE_POS.y, 7, 0);
		}
		for (let i = 0; i < props.length; i++) {
			const p = props[i];
			if (!p || p.world !== world) continue;
			if (p.hideFlag && flags[p.hideFlag]) continue;
			add(p.y, 2, i);
		}
		for (let i = 0; i < npcs.length; i++) if (npcs[i]?.world === world) add(npcs[i]?.y ?? 0, 5, i);
		if (mode !== "title" && !driven) add(player.y, 6, 0);
		order.length = dn;
		for (let i = 0; i < dn; i++) order[i] = i;
		order.sort((a, b) => (dlY[a] ?? 0) - (dlY[b] ?? 0));
		for (let n = 0; n < dn; n++) {
			const i = order[n] ?? 0;
			const k = dlK[i];
			const idx = dlI[i] ?? 0;
			if (k === 0) {
				const b = buildings[idx];
				if (b) ctx.drawImage(b.canvas, b.tx * TW, b.ty * TW);
			} else if (k === 1) {
				const tree = trees[idx];
				const spr = tree ? treeSprites[tree.v % treeSprites.length] : void 0;
				if (tree && spr) ctx.drawImage(spr, tree.x - 10, tree.y - 20);
			} else if (k === 2) {
				const prop = props[idx];
				if (prop) drawProp(prop);
			} else if (k === 3) {
				const car = cars[idx];
				if (car) drawCar(car);
			} else if (k === 4) {
				const punk = punks[idx];
				if (punk) drawPerson(punk.x, punk.y, punk.yaw, time * 10, "#3d8f45", "#1c2430", "#243044", "#e0b088", punk.hurt > 0);
			} else if (k === 5) {
				const npc = npcs[idx];
				if (npc) drawPerson(npc.x, npc.y, 0, time * 2, npc.shirt, npc.hair, npc.pants, npc.skin, false);
			} else if (k === 6) {
				drawPerson(player.x, player.y, player.yaw, time * 10, "#ff7a3c", "#5a3318", "#2c3348", "#f0c29a", player.iframes > 0 && (time * 20 | 0) % 2 === 0);
				if (player.swing > .12) {
					ctx.fillStyle = "#fff6ea";
					const fx = -Math.sin(player.yaw);
					const fy = -Math.cos(player.yaw);
					ctx.fillRect(player.x + fx * 12 - 2, player.y + fy * 12 - 2, 4, 4);
				}
			} else if (k === 7) drawCase(CASE_POS.x, CASE_POS.y);
		}
		if (world === "city") drawNeon();
		for (const p of portals) {
			if (p.world !== world) continue;
			const bob = Math.sin(time * 4 + p.x) * 2;
			const near = Math.hypot(p.x - player.x, p.y - player.y) < 46;
			ctx.fillStyle = near ? "#ffe14a" : "rgba(255,225,74,0.7)";
			ctx.fillRect(p.x - 3, p.y - 14 + bob, 6, 5);
			ctx.fillRect(p.x - 1, p.y - 9 + bob, 2, 5);
		}
		const gpoint = mode === "play" ? guide() : null;
		if (gpoint) {
			const bob = Math.sin(time * 5) * 3;
			ctx.fillStyle = "#ff3d6e";
			ctx.fillRect(gpoint.x - 3, gpoint.y - 20 + bob, 6, 6);
			ctx.fillStyle = "#fff6ea";
			ctx.fillRect(gpoint.x - 1, gpoint.y - 14 + bob, 2, 6);
		}
		for (const p of particles) {
			if (p.life <= 0) continue;
			ctx.globalAlpha = Math.max(0, p.life / p.max);
			ctx.fillStyle = p.color;
			ctx.fillRect(p.x | 0, p.y | 0, p.size, p.size);
			ctx.globalAlpha = 1;
		}
		ctx.font = "8px ui-monospace, monospace";
		for (const f of floats) {
			if (f.life <= 0) continue;
			ctx.globalAlpha = Math.max(0, f.life / .7);
			ctx.fillStyle = f.color;
			ctx.fillText(f.text, f.x, f.y);
			ctx.globalAlpha = 1;
		}
		ctx.restore();
		if (gpoint && mode === "play") {
			const sx = gpoint.x - camX;
			const sy = gpoint.y - camY;
			const pad = 16;
			if (!(sx > pad && sy > pad && sx < viewW - pad && sy < viewH - pad)) {
				const ang = Math.atan2(sy - viewH / 2, sx - viewW / 2);
				const ex = clamp(viewW / 2 + Math.cos(ang) * viewW * .42, pad, viewW - pad);
				const ey = clamp(viewH / 2 + Math.sin(ang) * viewH * .36, pad, viewH - pad);
				ctx.save();
				ctx.translate(ex, ey);
				ctx.rotate(ang);
				ctx.fillStyle = "#ffc83d";
				ctx.beginPath();
				ctx.moveTo(9, 0);
				ctx.lineTo(-7, 5);
				ctx.lineTo(-7, -5);
				ctx.fill();
				ctx.restore();
			}
		}
		fadeEl.style.opacity = String(fade);
		if (mode === "play") paintHud();
		if (mapOpen) paintBig();
		paintMini();
	}
	function paintHud() {
		const copy = goalCopy(goal());
		const gp = guide();
		let extra = "";
		if (gp) extra = ` · ${Math.round(Math.hypot(gp.x - player.x, gp.y - player.y) / 16)} м`;
		missionKicker.textContent = `Миссия ${copy.n}/6`;
		missionText.textContent = copy.text + extra;
		moneyVal.textContent = `$${money}`;
		hpFill.style.width = `${clamp(player.hp, 0, 100)}%`;
		hpNum.textContent = String(Math.ceil(player.hp));
		const act = findBest();
		if (act && !dialog && !mapOpen) {
			hintEl.textContent = act.hint;
			hintEl.classList.remove("is-hidden");
		} else hintEl.classList.add("is-hidden");
		syncVehicleUi();
	}
	function paintMini() {
		const w = mini.width;
		const h = mini.height;
		mctx.imageSmoothingEnabled = false;
		mctx.fillStyle = "#120818";
		mctx.fillRect(0, 0, w, h);
		mctx.drawImage(miniStatic, 0, 0, w, h);
		const sx = w / COLS;
		const sy = h / ROWS;
		if (world === "city") {
			mctx.fillStyle = "#ff3d6e";
			mctx.fillRect(player.x / TW * sx - 1.5, player.y / TW * sy - 1.5, 3, 3);
			const gp = guide();
			if (gp && mode === "play") {
				mctx.fillStyle = "#ffe14a";
				mctx.fillRect(gp.x / TW * sx - 1.5, gp.y / TW * sy - 1.5, 3, 3);
			}
		} else {
			const door = doorOf(world);
			mctx.fillStyle = "#ff3d6e";
			mctx.fillRect(door.x / TW * sx - 2, door.y / TW * sy - 2, 4, 4);
		}
	}
	function paintBig() {
		const w = big.width;
		const h = big.height;
		bctx.imageSmoothingEnabled = false;
		bctx.fillStyle = "#120818";
		bctx.fillRect(0, 0, w, h);
		bctx.drawImage(miniStatic, 0, 0, w, h);
		const sx = w / COLS;
		const sy = h / ROWS;
		bctx.font = "12px Trebuchet MS, Segoe UI, sans-serif";
		for (const [tx, ty, text] of [
			[
				19,
				5,
				"Квартира"
			],
			[
				41,
				18,
				"Жирный карп"
			],
			[
				62,
				31,
				"Неон"
			],
			[
				19,
				32,
				"Склад"
			],
			[
				18,
				45,
				"Роща"
			],
			[
				28,
				51,
				"Река"
			],
			[
				51,
				51,
				"Мост"
			],
			[
				18,
				63,
				"Лес"
			],
			[
				58,
				64,
				"Просека"
			]
		]) {
			const x = Number(tx) * sx;
			const y = Number(ty) * sy;
			bctx.fillStyle = "rgba(18,8,24,0.72)";
			bctx.fillRect(x, y - 10, bctx.measureText(String(text)).width + 6, 14);
			bctx.fillStyle = "#fff6ea";
			bctx.fillText(String(text), x + 3, y);
		}
		if (world === "city") {
			bctx.fillStyle = "#ff3d6e";
			bctx.fillRect(player.x / TW * sx - 3, player.y / TW * sy - 3, 6, 6);
		}
		const gp = guide();
		if (gp) {
			bctx.fillStyle = "#ffe14a";
			bctx.fillRect(gp.x / TW * sx - 3, gp.y / TW * sy - 3, 6, 6);
		}
		for (const car of cars) {
			if (!car.alive) continue;
			bctx.fillStyle = car.color;
			bctx.fillRect(car.x / TW * sx - 2, car.y / TW * sy - 2, 4, 4);
		}
	}
	function drawDecal(d) {
		if (d.k === "dashH") {
			ctx.fillStyle = "#f4f1ea";
			ctx.fillRect(d.x, d.y, 8, 2);
		} else if (d.k === "dashV") {
			ctx.fillStyle = "#f4f1ea";
			ctx.fillRect(d.x, d.y, 2, 8);
		} else if (d.k === "stripe") {
			ctx.fillStyle = "#f7f4ee";
			ctx.fillRect(d.x, d.y, 10, 3);
		} else if (d.k === "flower") {
			ctx.fillStyle = d.a && d.a > .5 ? "#ff5d8f" : "#ffe14a";
			ctx.fillRect(d.x, d.y, 2, 2);
			ctx.fillStyle = "#2f7a34";
			ctx.fillRect(d.x, d.y + 2, 1, 2);
		} else if (d.k === "manhole") {
			ctx.fillStyle = "#2a2a32";
			ctx.fillRect(d.x, d.y, 8, 8);
			ctx.fillStyle = "#8d8d96";
			ctx.fillRect(d.x + 2, d.y + 2, 4, 4);
		} else if (d.k === "reed") {
			ctx.fillStyle = "#2f6a38";
			ctx.fillRect(d.x, d.y, 1, 5);
			ctx.fillRect(d.x + 2, d.y + 1, 1, 4);
		} else if (d.k === "trash") {
			ctx.fillStyle = "#6a6a72";
			ctx.fillRect(d.x, d.y, 4, 3);
			ctx.fillStyle = "#c9a227";
			ctx.fillRect(d.x + 1, d.y - 1, 2, 1);
		} else if (d.k === "blood") {
			ctx.fillStyle = "#b4233a";
			ctx.fillRect(d.x, d.y, 4, 3);
			ctx.fillRect(d.x + 3, d.y - 2, 2, 2);
			ctx.fillRect(d.x - 2, d.y + 2, 2, 2);
		} else if (d.k === "park") {
			ctx.fillStyle = "#f4f1ea";
			ctx.fillRect(d.x, d.y, 2, 10);
		}
	}
	function drawProp(p) {
		const x = p.x;
		const y = p.y;
		if (p.kind === "bed") {
			ctx.fillStyle = "#8d4b3a";
			ctx.fillRect(x - 12, y - 8, 24, 16);
			ctx.fillStyle = "#f2efe6";
			ctx.fillRect(x - 10, y - 6, 10, 12);
			ctx.fillStyle = "#d98b7a";
			ctx.fillRect(x + 1, y - 6, 10, 12);
		} else if (p.kind === "table") {
			ctx.fillStyle = "#8a5a32";
			ctx.fillRect(x - 10, y - 7, 20, 14);
			ctx.fillStyle = "#c9844a";
			ctx.fillRect(x - 8, y - 5, 16, 10);
		} else if (p.kind === "sofa") {
			ctx.fillStyle = "#6a3a86";
			ctx.fillRect(x - 14, y - 7, 28, 14);
			ctx.fillStyle = "#8d58a8";
			ctx.fillRect(x - 12, y - 5, 24, 8);
		} else if (p.kind === "tv") {
			ctx.fillStyle = "#242833";
			ctx.fillRect(x - 8, y - 6, 16, 12);
			ctx.fillStyle = "#79c7ea";
			ctx.fillRect(x - 6, y - 4, 12, 8);
		} else if (p.kind === "counter" || p.kind === "bar") {
			ctx.fillStyle = p.kind === "bar" ? "#2a2044" : "#c45a32";
			ctx.fillRect(x - p.hw, y - p.hh, p.hw * 2, p.hh * 2);
			ctx.fillStyle = p.kind === "bar" ? "#ff3d8a" : "#f0d29a";
			ctx.fillRect(x - p.hw + 2, y - p.hh + 2, p.hw * 2 - 4, 3);
		} else if (p.kind === "crate") {
			ctx.fillStyle = "#a8743c";
			ctx.fillRect(x - p.hw, y - p.hh, p.hw * 2, p.hh * 2);
			ctx.fillStyle = "#6b4524";
			ctx.fillRect(x - 1, y - p.hh, 2, p.hh * 2);
			ctx.fillRect(x - p.hw, y - 1, p.hw * 2, 2);
		} else if (p.kind === "safe") {
			ctx.fillStyle = flags.safe ? "#3a4550" : "#22303a";
			ctx.fillRect(x - 10, y - 12, 20, 22);
			ctx.fillStyle = flags.rita && flags.case ? "#ffe14a" : "#8fd4c8";
			ctx.fillRect(x - 3, y - 2, 6, 6);
			ctx.fillStyle = "#d0d6dc";
			ctx.fillRect(x + 4, y - 8, 2, 5);
		} else if (p.kind === "plant") {
			ctx.fillStyle = "#6a4030";
			ctx.fillRect(x - 3, y - 2, 6, 6);
			ctx.fillStyle = "#2f9a4a";
			ctx.fillRect(x - 5, y - 10, 10, 8);
		} else if (p.kind === "speaker") {
			ctx.fillStyle = "#1b1b22";
			ctx.fillRect(x - 5, y - 8, 10, 16);
			ctx.fillStyle = "#ff3d6e";
			ctx.beginPath();
			ctx.arc(x, y - 2, 3, 0, Math.PI * 2);
			ctx.fill();
		} else if (p.kind === "pager") {
			ctx.fillStyle = "#1c1c24";
			ctx.fillRect(x - 6, y - 4, 12, 8);
			ctx.fillStyle = "#9dff6a";
			ctx.fillRect(x - 4, y - 2, 8, 4);
		} else if (p.kind === "cash") {
			ctx.fillStyle = "#1f8f4a";
			ctx.fillRect(x - 6, y - 4, 12, 8);
			ctx.fillStyle = "#d8ffe4";
			ctx.fillRect(x - 2, y - 2, 4, 4);
		} else if (p.kind === "radio") {
			ctx.fillStyle = "#3a2a24";
			ctx.fillRect(x - 7, y - 5, 14, 10);
			ctx.fillStyle = "#ffc83d";
			ctx.fillRect(x + 3, y - 3, 2, 6);
		} else if (p.kind === "sauce") {
			ctx.fillStyle = "#d23b2e";
			ctx.fillRect(x - 3, y - 6, 6, 10);
			ctx.fillStyle = "#f2d07a";
			ctx.fillRect(x - 2, y - 8, 4, 2);
		} else if (p.kind === "menu") {
			ctx.fillStyle = "#f3e2b0";
			ctx.fillRect(x - 6, y - 8, 12, 14);
			ctx.fillStyle = "#c4493a";
			ctx.fillRect(x - 4, y - 5, 8, 2);
		} else if (p.kind === "boat") {
			ctx.fillStyle = "#f2efe6";
			ctx.fillRect(x - 10, y - 4, 20, 8);
			ctx.fillStyle = "#3c92d8";
			ctx.fillRect(x - 12, y + 2, 24, 2);
			ctx.fillStyle = "#c45a32";
			ctx.fillRect(x - 1, y - 10, 2, 8);
		} else if (p.kind === "lamp") {
			ctx.fillStyle = "#2c3144";
			ctx.fillRect(x - 1, y - 8, 2, 14);
			ctx.fillStyle = "#ffe9a0";
			ctx.fillRect(x - 3, y - 10, 6, 3);
		} else if (p.kind === "bench") {
			ctx.fillStyle = "#6b4630";
			ctx.fillRect(x - 10, y - 3, 20, 6);
			ctx.fillStyle = "#3e2a1e";
			ctx.fillRect(x - 8, y + 3, 2, 3);
			ctx.fillRect(x + 6, y + 3, 2, 3);
		}
	}
	function drawCase(x, y) {
		const bob = Math.sin(time * 3) * 1;
		ctx.fillStyle = "rgba(20,8,28,0.35)";
		ctx.fillRect(x - 6, y + 4, 12, 3);
		ctx.fillStyle = "#c9843a";
		ctx.fillRect(x - 6, y - 5 + bob, 12, 9);
		ctx.fillStyle = "#f0d29a";
		ctx.fillRect(x - 1, y - 2 + bob, 2, 3);
	}
	function drawCar(car) {
		ctx.save();
		ctx.translate(Math.round(car.x), Math.round(car.y));
		ctx.rotate(-car.yaw);
		ctx.fillStyle = "rgba(20,8,28,0.35)";
		ctx.fillRect(-8, -8, 16, 20);
		ctx.fillStyle = "#16161c";
		ctx.fillRect(-8, -11, 3, 5);
		ctx.fillRect(5, -11, 3, 5);
		ctx.fillRect(-8, 6, 3, 5);
		ctx.fillRect(5, 6, 3, 5);
		ctx.fillStyle = car.color;
		const long = car.kind === "sport" ? 20 : 18;
		ctx.fillRect(-6, -9, 12, long);
		ctx.fillStyle = car.kind === "sport" ? "#ffd0dc" : "#d5e7f2";
		ctx.fillRect(-5, -3, 10, 7);
		ctx.fillStyle = "#8fd4f5";
		ctx.fillRect(-5, -8, 10, 3);
		ctx.fillStyle = "#243044";
		ctx.fillRect(-5, 6, 10, 2);
		if (car.kind === "taxi") {
			ctx.fillStyle = "#222";
			ctx.fillRect(-3, -1, 6, 3);
			ctx.fillStyle = "#fff";
			ctx.fillRect(-2, 0, 4, 1);
		}
		if (car.kind === "chase") {
			ctx.fillStyle = "#1a1a1a";
			ctx.fillRect(-6, -1, 12, 2);
		}
		if (car.occupied) {
			ctx.fillStyle = "#f0c29a";
			ctx.fillRect(-2, -2, 4, 4);
			ctx.fillStyle = "#5a3318";
			ctx.fillRect(-2, -3, 4, 2);
		}
		ctx.restore();
	}
	function drawPerson(x, y, yaw, walk, shirt, hair, pants, skin, hurt) {
		ctx.fillStyle = "rgba(20,8,28,0.35)";
		ctx.beginPath();
		ctx.ellipse(x, y + 5, 6, 3, 0, 0, Math.PI * 2);
		ctx.fill();
		ctx.save();
		ctx.translate(Math.round(x), Math.round(y));
		ctx.rotate(-yaw);
		const bob = Math.sin(walk) * 1.2;
		ctx.fillStyle = hurt ? "#ffffff" : pants;
		ctx.fillRect(-4, 1, 3, 5);
		ctx.fillRect(1, 1 - bob, 3, 5);
		ctx.fillStyle = hurt ? "#ffffff" : shirt;
		ctx.fillRect(-5, -5, 10, 7);
		ctx.fillStyle = skin;
		ctx.fillRect(-3, -10, 6, 6);
		ctx.fillStyle = hair;
		ctx.fillRect(-4, -11, 7, 3);
		ctx.fillStyle = "#1a1020";
		ctx.fillRect(-2, -8, 1, 1);
		ctx.fillRect(1, -8, 1, 1);
		ctx.restore();
	}
	function drawNeon() {
		const flick = Math.sin(time * 16) > -.15;
		ctx.fillStyle = flick ? "#ff3d8a" : "#6a2048";
		ctx.fillRect(898, 474, 36, 6);
		ctx.fillStyle = flick ? "#7ad0ff" : "#24344c";
		ctx.fillRect(904, 482, 24, 4);
	}
	function drawPortrait(who) {
		pctx.imageSmoothingEnabled = false;
		pctx.fillStyle = "#241536";
		pctx.fillRect(0, 0, 32, 32);
		const skin = "#f0c29a";
		const shirt = who === "keks" ? "#ff7a3c" : who === "lyokha" ? "#f2efe6" : who === "rita" ? "#ff3d8a" : who === "punk" ? "#3d8f45" : who === "kolya" ? "#e0b030" : "#2a2044";
		if (who === "pager") {
			pctx.fillStyle = "#111118";
			pctx.fillRect(6, 8, 20, 16);
			pctx.fillStyle = "#9dff6a";
			pctx.fillRect(8, 10, 16, 8);
			pctx.fillStyle = "#3a3a44";
			pctx.fillRect(9, 20, 3, 2);
			pctx.fillRect(14, 20, 3, 2);
			pctx.fillRect(19, 20, 3, 2);
			return;
		}
		pctx.fillStyle = shirt;
		pctx.fillRect(8, 20, 16, 10);
		pctx.fillStyle = skin;
		pctx.fillRect(10, 8, 12, 12);
		pctx.fillStyle = who === "rita" ? "#1a1424" : who === "kolya" ? "#3a2a20" : who === "punk" ? "#203028" : who === "lyokha" ? "#3a2c24" : "#5a3318";
		if (who === "kolya") pctx.fillRect(10, 6, 12, 3);
		else if (who === "rita") pctx.fillRect(8, 6, 16, 8);
		else pctx.fillRect(10, 6, 12, 5);
		pctx.fillStyle = "#1a1020";
		pctx.fillRect(13, 13, 2, 2);
		pctx.fillRect(18, 13, 2, 2);
		if (who === "kolya") {
			pctx.fillStyle = "#2a1a14";
			pctx.fillRect(12, 17, 8, 2);
		}
		if (who === "punk") {
			pctx.fillStyle = "#1c2430";
			pctx.fillRect(9, 7, 14, 4);
		}
		if (who === "lyokha") {
			pctx.fillStyle = "#c4493a";
			pctx.fillRect(9, 5, 14, 3);
		}
	}
	function tileAt(map, tx, ty) {
		if (tx < 0 || ty < 0 || tx >= map.cols || ty >= map.rows) return T.WALL;
		return map.tiles[ty * map.cols + tx] ?? T.WALL;
	}
	function setTile(map, tx, ty, tile) {
		if (tx < 0 || ty < 0 || tx >= map.cols || ty >= map.rows) return;
		map.tiles[ty * map.cols + tx] = tile;
	}
	function fillRect(map, x, y, w, h, tile) {
		for (let ty = y; ty < y + h; ty++) for (let tx = x; tx < x + w; tx++) setTile(map, tx, ty, tile);
	}
	function buildWorld() {
		const city = {
			cols: COLS,
			rows: ROWS,
			tiles: /* @__PURE__ */ new Uint8Array(6192)
		};
		city.tiles.fill(T.FOREST);
		fillRect(city, 0, 0, 75, 41, T.WALK);
		fillRect(city, 75, 0, 11, 49, T.GRASS);
		fillRect(city, 0, 41, COLS, 8, T.GRASS);
		fillRect(city, 0, 49, COLS, 1, T.SAND);
		fillRect(city, 0, 50, COLS, 4, T.WATER);
		fillRect(city, 0, 54, COLS, 1, T.SAND);
		for (const y0 of [
			10,
			24,
			36
		]) fillRect(city, 0, y0, COLS, 4, T.ROAD);
		for (const x0 of [
			6,
			28,
			70
		]) fillRect(city, x0, 0, 4, 41, T.ROAD);
		fillRect(city, 50, 0, 4, 50, T.ROAD);
		fillRect(city, 50, 50, 4, 4, T.BRIDGE);
		fillRect(city, 50, 54, 4, 15, T.DIRT);
		for (let y = 16; y <= 22; y++) for (let x = 76; x <= 84; x++) if ((city.tiles[y * COLS + x] ?? 0) !== T.ROAD) setTile(city, x, y, T.PARK);
		for (let y = 29; y <= 34; y++) for (let x = 76; x <= 84; x++) if ((city.tiles[y * COLS + x] ?? 0) !== T.ROAD) setTile(city, x, y, T.PARK);
		maps.city = city;
		for (const d of [
			{
				tx: 11,
				ty: 1,
				tw: 16,
				th: 8,
				style: "apt",
				to: "apt",
				label: "Квартира"
			},
			{
				tx: 33,
				ty: 1,
				tw: 16,
				th: 8,
				style: "shop"
			},
			{
				tx: 55,
				ty: 1,
				tw: 14,
				th: 8,
				style: "house"
			},
			{
				tx: 11,
				ty: 15,
				tw: 16,
				th: 8,
				style: "generic"
			},
			{
				tx: 33,
				ty: 15,
				tw: 16,
				th: 8,
				style: "diner",
				to: "diner",
				label: "Жирный карп"
			},
			{
				tx: 55,
				ty: 15,
				tw: 14,
				th: 8,
				style: "shop"
			},
			{
				tx: 11,
				ty: 29,
				tw: 16,
				th: 6,
				style: "warehouse",
				to: "ware",
				label: "Склад"
			},
			{
				tx: 33,
				ty: 29,
				tw: 16,
				th: 6,
				style: "generic"
			},
			{
				tx: 55,
				ty: 29,
				tw: 14,
				th: 6,
				style: "club",
				to: "club",
				label: "Неон"
			},
			{
				tx: 76,
				ty: 1,
				tw: 8,
				th: 8,
				style: "shop"
			}
		]) {
			fillRect(city, d.tx, d.ty, d.tw, d.th, T.ROOF);
			const canvasB = paintBuilding(d.tw * TW, d.th * TW, d.style, d.tx * 17 + d.ty);
			buildings.push({
				...d,
				canvas: canvasB
			});
			if (!d.to || !d.label || d.to === "city") continue;
			const room = ROOMS[d.to];
			const doorTx = d.tx + Math.floor(d.tw / 2);
			const doorTy = d.ty + d.th;
			const dx = doorTx * TW + TW / 2;
			const dy = doorTy * TW + TW / 2;
			portals.push({
				world: "city",
				x: dx,
				y: dy,
				to: d.to,
				sx: room.sx,
				sy: room.sy,
				hint: `E — войти: ${d.label}`
			});
			portals.push({
				world: d.to,
				x: room.ex,
				y: room.ey,
				to: "city",
				sx: dx,
				sy: dy + 22,
				hint: "E — на улицу"
			});
		}
		for (const y0 of [
			10,
			24,
			36
		]) {
			const py = (y0 + 2) * TW;
			for (let x = 12; x < 1376; x += 22) if (tileAt(city, Math.floor(x / TW), y0 + 1) === T.ROAD) decals.push({
				world: "city",
				x,
				y: py,
				k: "dashH"
			});
		}
		for (const x0 of [
			6,
			28,
			50,
			70
		]) {
			const px = (x0 + 2) * TW;
			for (let y = 8; y < 640; y += 22) {
				const ty = Math.floor(y / TW);
				if (tileAt(city, x0 + 1, ty) === T.ROAD) decals.push({
					world: "city",
					x: px,
					y,
					k: "dashV"
				});
			}
		}
		for (const vx of [
			6,
			28,
			50,
			70
		]) for (const hy of [
			10,
			24,
			36
		]) {
			decals.push({
				world: "city",
				x: vx * TW + 4,
				y: (hy + 4) * TW + 2,
				k: "stripe"
			});
			decals.push({
				world: "city",
				x: vx * TW + 16,
				y: (hy + 4) * TW + 2,
				k: "stripe"
			});
			decals.push({
				world: "city",
				x: vx * TW + 28,
				y: (hy + 4) * TW + 2,
				k: "stripe"
			});
		}
		const rnd = hash(7);
		for (let i = 0; i < 18; i++) {
			const tx = 2 + (rnd() * 70 | 0);
			const ty = 2 + (rnd() * 38 | 0);
			if (tileAt(city, tx, ty) === T.WALK) decals.push({
				world: "city",
				x: tx * TW + 4,
				y: ty * TW + 4,
				k: "manhole"
			});
		}
		for (let i = 0; i < 26; i++) {
			const tx = rnd() * COLS | 0;
			const ty = rnd() * ROWS | 0;
			const tile = tileAt(city, tx, ty);
			if (tile === T.GRASS || tile === T.FOREST) decals.push({
				world: "city",
				x: tx * TW + 4,
				y: ty * TW + 6,
				k: "flower",
				a: rnd()
			});
			if (tile === T.SAND && rnd() > .4) decals.push({
				world: "city",
				x: tx * TW + 3,
				y: ty * TW + 4,
				k: "reed"
			});
			if (tile === T.WALK && rnd() > .82) decals.push({
				world: "city",
				x: tx * TW + 6,
				y: ty * TW + 8,
				k: "trash"
			});
			if (tile === T.PARK) decals.push({
				world: "city",
				x: tx * TW + 4,
				y: ty * TW + 3,
				k: "park"
			});
		}
		for (let ty = 0; ty < ROWS; ty += 2) for (let tx = 0; tx < COLS; tx += 2) {
			const tile = tileAt(city, tx, ty);
			if (tile !== T.GRASS && tile !== T.FOREST) continue;
			if (rnd() > (ty > 55 ? .55 : .72)) continue;
			if (nearRoad(city, tx, ty)) continue;
			if (tx > 46 && tx < 58 && ty > 62) continue;
			if (tx > 8 && tx < 26 && ty > 42 && ty < 48 && rnd() > .4) continue;
			trees.push({
				x: tx * TW + 8,
				y: ty * TW + 10,
				r: 5,
				v: rnd() * 3 | 0
			});
		}
		maps.apt = carve(ROOMS.apt.cols, ROOMS.apt.rows, T.WOOD, 10, 11);
		fillRect(maps.apt, 15, 1, 6, 6, T.TILE);
		for (let y = 1; y <= 6; y++) if (y !== 4) setTile(maps.apt, 14, y, T.WALL);
		maps.diner = carve(ROOMS.diner.cols, ROOMS.diner.rows, T.CHECK, 9, 10);
		maps.club = carve(ROOMS.club.cols, ROOMS.club.rows, T.DARK, 10, 11);
		fillRect(maps.club, 6, 8, 10, 4, T.NEON);
		maps.ware = carve(ROOMS.ware.cols, ROOMS.ware.rows, T.CONC, 11, 12);
		props.push({
			world: "apt",
			x: 70,
			y: 52,
			hw: 12,
			hh: 8,
			kind: "bed",
			solid: true
		}, {
			world: "apt",
			x: 78,
			y: 96,
			hw: 10,
			hh: 7,
			kind: "table",
			solid: true
		}, {
			world: "apt",
			x: 140,
			y: 52,
			hw: 8,
			hh: 6,
			kind: "tv",
			solid: true
		}, {
			world: "apt",
			x: 270,
			y: 130,
			hw: 14,
			hh: 7,
			kind: "sofa",
			solid: true
		}, {
			world: "apt",
			x: 78,
			y: 86,
			hw: 6,
			hh: 4,
			kind: "pager",
			solid: false,
			hideFlag: "pager"
		}, {
			world: "apt",
			x: 250,
			y: 156,
			hw: 4,
			hh: 3,
			kind: "cash",
			solid: false,
			hideFlag: "cash"
		}, {
			world: "apt",
			x: 210,
			y: 112,
			hw: 6,
			hh: 4,
			kind: "radio",
			solid: false
		}, {
			world: "apt",
			x: 250,
			y: 70,
			hw: 4,
			hh: 4,
			kind: "plant",
			solid: false
		}, {
			world: "diner",
			x: 160,
			y: 78,
			hw: 78,
			hh: 10,
			kind: "counter",
			solid: true
		}, {
			world: "diner",
			x: 46,
			y: 160,
			hw: 4,
			hh: 6,
			kind: "sauce",
			solid: false
		}, {
			world: "diner",
			x: 40,
			y: 40,
			hw: 6,
			hh: 8,
			kind: "menu",
			solid: false
		}, {
			world: "club",
			x: 200,
			y: 58,
			hw: 70,
			hh: 10,
			kind: "bar",
			solid: true
		}, {
			world: "club",
			x: 40,
			y: 90,
			hw: 5,
			hh: 8,
			kind: "speaker",
			solid: true
		}, {
			world: "club",
			x: 300,
			y: 90,
			hw: 5,
			hh: 8,
			kind: "speaker",
			solid: true
		}, {
			world: "ware",
			x: 78,
			y: 90,
			hw: 12,
			hh: 12,
			kind: "crate",
			solid: true
		}, {
			world: "ware",
			x: 78,
			y: 140,
			hw: 12,
			hh: 12,
			kind: "crate",
			solid: true
		}, {
			world: "ware",
			x: 130,
			y: 90,
			hw: 10,
			hh: 10,
			kind: "crate",
			solid: true
		}, {
			world: "ware",
			x: 300,
			y: 72,
			hw: 10,
			hh: 12,
			kind: "safe",
			solid: true
		}, {
			world: "city",
			x: 220,
			y: 760,
			hw: 10,
			hh: 4,
			kind: "bench",
			solid: false
		}, {
			world: "city",
			x: 640,
			y: 820,
			hw: 10,
			hh: 4,
			kind: "boat",
			solid: false
		}, {
			world: "city",
			x: 180,
			y: 150,
			hw: 2,
			hh: 7,
			kind: "lamp",
			solid: false
		}, {
			world: "city",
			x: 520,
			y: 150,
			hw: 2,
			hh: 7,
			kind: "lamp",
			solid: false
		}, {
			world: "city",
			x: 900,
			y: 360,
			hw: 2,
			hh: 7,
			kind: "lamp",
			solid: false
		});
		npcs.push({
			id: "lyokha",
			world: "diner",
			x: 160,
			y: 118,
			name: "Лёха",
			shirt: "#f4f1ea",
			hair: "#3a2c24",
			pants: "#2c3348",
			skin: "#e0b088"
		}, {
			id: "rita",
			world: "club",
			x: 220,
			y: 96,
			name: "Рита",
			shirt: "#ff3d8a",
			hair: "#1a1424",
			pants: "#2a2038",
			skin: "#f0c29a"
		}, {
			id: "clubber",
			world: "club",
			x: 120,
			y: 170,
			name: "Тусовщик",
			shirt: "#7a5cff",
			hair: "#241c18",
			pants: "#1c1c24",
			skin: "#c99872"
		});
		makeCar("sedan", 220, 416, -Math.PI / 2, "#1ec8b8", "sedan", "parked");
		makeCar("taxi", 760, 192, -Math.PI / 2, "#ffc83d", "taxi", "loop");
		makeCar("sport", 900, 608, -Math.PI / 2, "#e23b32", "sport", "parked");
		makeCar("white", 1256, 296, Math.PI, "#f7f7fb", "white", "parked");
		resetPunks();
	}
	function nearRoad(map, tx, ty) {
		for (let y = ty - 1; y <= ty + 1; y++) for (let x = tx - 1; x <= tx + 1; x++) {
			const t = tileAt(map, x, y);
			if (t === T.ROAD || t === T.DIRT || t === T.BRIDGE || t === T.WATER || t === T.PARK || t === T.ROOF || t === T.WALK) return true;
		}
		return false;
	}
	function carve(cols, rows, floor, doorA, doorB) {
		const map = {
			cols,
			rows,
			tiles: new Uint8Array(cols * rows)
		};
		map.tiles.fill(floor);
		for (let x = 0; x < cols; x++) {
			setTile(map, x, 0, T.WALL);
			setTile(map, x, rows - 1, T.WALL);
		}
		for (let y = 0; y < rows; y++) {
			setTile(map, 0, y, T.WALL);
			setTile(map, cols - 1, y, T.WALL);
		}
		setTile(map, doorA, rows - 1, floor);
		setTile(map, doorB, rows - 1, floor);
		return map;
	}
	function renderMiniStatic() {
		const c = document.createElement("canvas");
		c.width = COLS;
		c.height = ROWS;
		const g = c.getContext("2d");
		if (!g) return c;
		const city = maps.city;
		for (let y = 0; y < ROWS; y++) for (let x = 0; x < COLS; x++) {
			g.fillStyle = miniColor(city?.tiles[y * COLS + x] ?? T.FOREST);
			g.fillRect(x, y, 1, 1);
		}
		g.fillStyle = "#1d6b32";
		for (const tree of trees) {
			const tx = tree.x / TW | 0;
			const ty = tree.y / TW | 0;
			g.fillRect(tx, ty, 1, 1);
		}
		return c;
	}
	function miniColor(tile) {
		switch (tile) {
			case T.ROAD: return "#3a3568";
			case T.PARK: return "#322c58";
			case T.WALK: return "#e2d2b0";
			case T.ROOF: return "#d5dbe6";
			case T.WATER: return "#3c92d8";
			case T.SAND: return "#e6d3a0";
			case T.FOREST: return "#2f8a45";
			case T.DIRT: return "#8a6240";
			case T.BRIDGE: return "#d2b07a";
			default: return "#63b84e";
		}
	}
	function syncTouch() {
		const coarse = window.matchMedia("(pointer: coarse)").matches;
		const narrow = root.clientWidth < 900;
		const on = touchMode === "on" || touchMode === "auto" && (coarse || narrow);
		touchEl.classList.toggle("is-hidden", !on || mode !== "play");
		root.classList.toggle("show-touch", on && mode === "play");
	}
	function resize() {
		const rect = root.getBoundingClientRect();
		const scale = rect.width < 520 ? 2 : rect.width < 1e3 ? 3 : 4;
		viewW = Math.max(160, Math.floor(rect.width / scale));
		viewH = Math.max(140, Math.floor(rect.height / scale));
		canvas.width = viewW;
		canvas.height = viewH;
		canvas.style.width = `${viewW * scale}px`;
		canvas.style.height = `${viewH * scale}px`;
		ctx.imageSmoothingEnabled = false;
		const maxW = Math.min(rect.width - 40, 920);
		const aspect = ROWS / COLS;
		let bw = maxW;
		let bh = bw * aspect;
		const maxH = Math.max(160, rect.height - 130);
		if (bh > maxH) {
			bh = maxH;
			bw = bh / aspect;
		}
		big.width = Math.max(COLS, Math.floor(bw));
		big.height = Math.max(ROWS, Math.floor(bh));
		syncTouch();
	}
	function toggleMap() {
		if (mode !== "play") return;
		mapOpen = !mapOpen;
		mapOverlay.classList.toggle("is-hidden", !mapOpen);
		if (mapOpen) paintBig();
	}
	function onKeyDown(e) {
		if (e.repeat) return;
		if ([
			"Space",
			"ArrowUp",
			"ArrowDown",
			"ArrowLeft",
			"ArrowRight"
		].includes(e.code)) e.preventDefault();
		if (mode === "play" && (e.code === "Enter" || e.code === "KeyE")) e.preventDefault();
		keys.add(e.code);
		unlock();
		if (mode === "play" && e.code === "KeyM") toggleMap();
		if (mode === "play" && e.code === "Escape") {
			if (mapOpen) toggleMap();
		}
	}
	function onKeyUp(e) {
		keys.delete(e.code);
	}
	window.addEventListener("keydown", onKeyDown, { signal });
	window.addEventListener("keyup", onKeyUp, { signal });
	window.addEventListener("blur", () => keys.clear(), { signal });
	document.addEventListener("visibilitychange", () => {
		if (document.visibilityState === "visible") unlock();
	}, { signal });
	must("#start-btn").addEventListener("click", () => {
		unlock();
		newGame();
	}, { signal });
	continueBtn.addEventListener("click", () => {
		unlock();
		if (!load()) return;
		dialog = null;
		renderDialog();
		beginPlay();
		showBanner("Смена продолжается. Район ничего не забыл.");
	}, { signal });
	must("#retry-btn").addEventListener("click", () => {
		unlock();
		newGame();
	}, { signal });
	must("#dlg-next").addEventListener("click", () => {
		unlock();
		advance();
	}, { signal });
	must("#map-btn").addEventListener("click", (e) => {
		e.stopPropagation();
		toggleMap();
	}, { signal });
	must("#close-map").addEventListener("click", () => {
		mapOpen = false;
		mapOverlay.classList.add("is-hidden");
	}, { signal });
	mini.parentElement?.addEventListener("pointerdown", (e) => {
		e.stopPropagation();
		e.preventDefault();
		toggleMap();
	}, { signal });
	soundBtn.addEventListener("click", () => {
		muted = !muted;
		soundBtn.classList.toggle("is-muted", muted);
		if (!muted) unlock();
	}, { signal });
	must("#touch-toggle").addEventListener("click", () => {
		touchMode = touchMode === "on" ? "off" : "on";
		syncTouch();
	}, { signal });
	const setJoyFromEvent = (e) => {
		const dx = e.clientX - joyOrigin.x;
		const dy = e.clientY - joyOrigin.y;
		const max = 40;
		const len = Math.hypot(dx, dy);
		if (len < 3) {
			joy.x = 0;
			joy.y = 0;
			knob.style.transform = "translate(0px, 0px)";
			return;
		}
		const mag = Math.min(max, len);
		joy.x = dx / len * (mag / max);
		joy.y = dy / len * (mag / max);
		knob.style.transform = `translate(${dx / len * mag}px, ${dy / len * mag}px)`;
	};
	joyEl.addEventListener("pointerdown", (e) => {
		joyId = e.pointerId;
		joyEl.setPointerCapture(e.pointerId);
		const rect = joyEl.getBoundingClientRect();
		joyOrigin.x = rect.left + rect.width / 2;
		joyOrigin.y = rect.top + rect.height / 2;
		setJoyFromEvent(e);
		e.preventDefault();
	}, { signal });
	window.addEventListener("pointermove", (e) => {
		if (joyId !== e.pointerId) return;
		setJoyFromEvent(e);
	}, { signal });
	const endJoy = (e) => {
		if (joyId !== e.pointerId) return;
		joyId = null;
		joy.x = 0;
		joy.y = 0;
		knob.style.transform = "translate(0px, 0px)";
	};
	window.addEventListener("pointerup", endJoy, { signal });
	window.addEventListener("pointercancel", endJoy, { signal });
	const bindHold = (el, down, up) => {
		el.addEventListener("pointerdown", (e) => {
			e.preventDefault();
			e.stopPropagation();
			el.setPointerCapture(e.pointerId);
			unlock();
			down();
		}, { signal });
		el.addEventListener("pointerup", up, { signal });
		el.addEventListener("pointercancel", up, { signal });
	};
	btnAct.addEventListener("pointerdown", (e) => {
		e.preventDefault();
		e.stopPropagation();
		unlock();
		actionEdge = true;
	}, { signal });
	bindHold(btnAtk, () => {
		atkHeld = true;
		atkEdge = true;
	}, () => {
		atkHeld = false;
	});
	bindHold(btnBrake, () => {
		brakeHeld = true;
	}, () => {
		brakeHeld = false;
	});
	btnHorn.addEventListener("pointerdown", (e) => {
		e.preventDefault();
		e.stopPropagation();
		hornEdge = true;
	}, { signal });
	canvas.addEventListener("pointerdown", (e) => {
		if (e.button !== 0 || mode !== "play") return;
		unlock();
		if (dialog) {
			actionEdge = true;
			return;
		}
		if (mapOpen) return;
		if (root.classList.contains("show-touch")) return;
		mouseDown = true;
		if (!driven) atkEdge = true;
	}, { signal });
	window.addEventListener("pointerup", () => {
		mouseDown = false;
	}, { signal });
	canvas.addEventListener("contextmenu", (e) => e.preventDefault(), { signal });
	const ro = new ResizeObserver(() => resize());
	ro.observe(root);
	resize();
	if (localStorage.getItem(SAVE_KEY)) continueBtn.disabled = false;
	window.__controlsTest = {
		getYaw: () => driven ? driven.yaw : player.yaw,
		getSpeed: () => driven ? driven.speed : Math.hypot(player.vx, player.vy),
		setSteer: (v) => {
			forcedSteer = clamp(v, -1, 1);
			steerForced = true;
		},
		setKeys: (codes) => {
			keys.clear();
			for (const code of codes) keys.add(code);
		}
	};
	let last = performance.now();
	let acc = 0;
	let raf = 0;
	const frame = (now) => {
		raf = requestAnimationFrame(frame);
		const dt = Math.min(.05, (now - last) / 1e3);
		last = now;
		if (hitStop > 0) {
			hitStop -= dt;
			render();
			return;
		}
		acc += dt;
		let steps = 0;
		while (acc >= 1 / 60 && steps < 5) {
			update(1 / 60);
			acc -= 1 / 60;
			steps += 1;
		}
		render();
	};
	raf = requestAnimationFrame(frame);
	return () => {
		ac.abort();
		ro.disconnect();
		cancelAnimationFrame(raf);
		delete window.__controlsTest;
		if (eng) try {
			eng.stop();
		} catch {}
		if (audioCtx) audioCtx.close();
	};
}
function buildTileSprites() {
	const sprites = [];
	const paint = (tile, alt = false) => {
		const { c, g } = sheet(TW, TW);
		const rnd = hash(tile * 99 + (alt ? 3 : 1));
		if (tile === T.GRASS) {
			g.fillStyle = "#63b84e";
			g.fillRect(0, 0, TW, TW);
			g.fillStyle = "#7dce62";
			for (let i = 0; i < 8; i++) g.fillRect(rnd() * TW | 0, rnd() * TW | 0, 1, 1);
		} else if (tile === T.FOREST) {
			g.fillStyle = "#2f7a3e";
			g.fillRect(0, 0, TW, TW);
			g.fillStyle = "#256838";
			for (let i = 0; i < 8; i++) g.fillRect(rnd() * TW | 0, rnd() * TW | 0, 2, 1);
		} else if (tile === T.ROAD || tile === T.PARK) {
			g.fillStyle = tile === T.PARK ? "#322c5c" : "#342c60";
			g.fillRect(0, 0, TW, TW);
			g.fillStyle = "rgba(255,255,255,0.05)";
			for (let i = 0; i < 6; i++) g.fillRect(rnd() * TW | 0, rnd() * TW | 0, 1, 1);
		} else if (tile === T.WALK) {
			g.fillStyle = "#e2d2b0";
			g.fillRect(0, 0, TW, TW);
			g.fillStyle = "rgba(90,60,40,0.18)";
			for (let i = 0; i < 7; i++) g.fillRect(rnd() * TW | 0, rnd() * TW | 0, 1, 1);
		} else if (tile === T.ROOF) {
			g.fillStyle = "#d5dbe6";
			g.fillRect(0, 0, TW, TW);
		} else if (tile === T.WATER) {
			g.fillStyle = alt ? "#4aa0e4" : "#3c92d8";
			g.fillRect(0, 0, TW, TW);
			g.fillStyle = alt ? "#d8f4ff" : "#8fd4f5";
			g.fillRect(0, alt ? 4 : 9, TW, 2);
			g.fillRect(0, alt ? 12 : 2, 6, 1);
		} else if (tile === T.SAND) {
			g.fillStyle = "#e6d3a0";
			g.fillRect(0, 0, TW, TW);
			g.fillStyle = "#c9a86a";
			for (let i = 0; i < 5; i++) g.fillRect(rnd() * TW | 0, rnd() * TW | 0, 1, 1);
		} else if (tile === T.DIRT) {
			g.fillStyle = "#8a6240";
			g.fillRect(0, 0, TW, TW);
			g.fillStyle = "#a67c52";
			g.fillRect(0, 7, TW, 2);
			g.fillStyle = "#5c4030";
			for (let i = 0; i < 4; i++) g.fillRect(rnd() * TW | 0, rnd() * TW | 0, 2, 1);
		} else if (tile === T.BRIDGE) {
			g.fillStyle = "#b88858";
			g.fillRect(0, 0, TW, TW);
			g.fillStyle = "#8a6238";
			g.fillRect(0, 0, 2, TW);
			g.fillRect(14, 0, 2, TW);
			g.fillStyle = "#d7b07a";
			g.fillRect(3, 4, 10, 2);
			g.fillRect(3, 10, 10, 2);
		} else if (tile === T.WALL) {
			g.fillStyle = "#4a3d58";
			g.fillRect(0, 0, TW, TW);
			g.fillStyle = "#6a5878";
			g.fillRect(0, 0, TW, 3);
			g.fillStyle = "#2e243c";
			g.fillRect(0, 13, TW, 3);
		} else if (tile === T.WOOD) {
			g.fillStyle = "#c48a52";
			g.fillRect(0, 0, TW, TW);
			g.fillStyle = "#a86e3c";
			for (let y = 3; y < TW; y += 4) g.fillRect(0, y, TW, 1);
		} else if (tile === T.TILE) {
			g.fillStyle = "#d7e4ea";
			g.fillRect(0, 0, TW, TW);
			g.fillStyle = "#b7c9d2";
			g.fillRect(0, 0, TW, 1);
			g.fillRect(0, 8, TW, 1);
			g.fillRect(0, 0, 1, TW);
			g.fillRect(8, 0, 1, TW);
		} else if (tile === T.CONC) {
			g.fillStyle = "#8d939c";
			g.fillRect(0, 0, TW, TW);
			g.fillStyle = "#6e7580";
			g.fillRect(0, 0, TW, 1);
			for (let i = 0; i < 5; i++) g.fillRect(rnd() * TW | 0, rnd() * TW | 0, 1, 1);
		} else if (tile === T.CHECK) for (let y = 0; y < TW; y += 8) for (let x = 0; x < TW; x += 8) {
			g.fillStyle = (x + y) % 16 === 0 ? "#f2efe6" : "#d24a3c";
			g.fillRect(x, y, 8, 8);
		}
		else if (tile === T.DARK) {
			g.fillStyle = "#24182f";
			g.fillRect(0, 0, TW, TW);
			g.fillStyle = "#3a2450";
			for (let i = 0; i < 4; i++) g.fillRect(rnd() * TW | 0, rnd() * TW | 0, 1, 1);
		} else if (tile === T.NEON) {
			g.fillStyle = "#2a1844";
			g.fillRect(0, 0, TW, TW);
			g.fillStyle = alt ? "#ff3d8a" : "#7ad0ff";
			g.fillRect(2, 2, 12, 12);
		} else {
			g.fillStyle = "#63b84e";
			g.fillRect(0, 0, TW, TW);
		}
		return c;
	};
	for (let i = 0; i <= T.NEON; i++) sprites[i] = paint(i, false);
	sprites[T.WATER + 20] = paint(T.WATER, true);
	return sprites;
}
function buildTreeSprites() {
	return [
		0,
		1,
		2
	].map((v) => {
		const { c, g } = sheet(20, 24);
		g.fillStyle = "rgba(20,8,28,0.3)";
		g.fillRect(4, 18, 12, 4);
		g.fillStyle = "#6b4630";
		g.fillRect(9, 12, 2, 8);
		g.fillStyle = v === 0 ? "#2f9a46" : v === 1 ? "#1f7a38" : "#46b85a";
		g.fillRect(2, 4, 16, 12);
		g.fillStyle = v === 2 ? "#7dce62" : "#1d6b32";
		g.fillRect(4, 2, 12, 6);
		g.fillRect(6, 6, 4, 3);
		return c;
	});
}
function paintBuilding(w, h, style, seed) {
	const pad = style === "warehouse" || style === "club" ? 0 : 8;
	const { c, g } = sheet(w, h + pad);
	const rnd = hash(seed);
	const p = {
		apt: {
			roof: "#d7deea",
			wall: "#8e97a8",
			win: "#6ec8e8",
			accent: "#e23d3d"
		},
		shop: {
			roof: "#efe0c8",
			wall: "#b08968",
			win: "#8fd0ea",
			accent: "#e23d3d"
		},
		diner: {
			roof: "#f0d060",
			wall: "#c45a32",
			win: "#9ad7ef",
			accent: "#fff6ea"
		},
		club: {
			roof: "#2a2048",
			wall: "#1a1430",
			win: "#7aa2ff",
			accent: "#ff3d8a"
		},
		warehouse: {
			roof: "#8b929c",
			wall: "#5c636c",
			win: "#d5dde4",
			accent: "#e0a030"
		},
		house: {
			roof: "#f0d2c0",
			wall: "#c46a4a",
			win: "#9ad0ea",
			accent: "#3d6b4f"
		},
		generic: {
			roof: "#cfd6e2",
			wall: "#7d8796",
			win: "#79c4e0",
			accent: "#de4d4d"
		}
	}[style];
	g.fillStyle = p.roof;
	g.fillRect(0, 0, w, h);
	for (let i = 0; i < w * h / 10; i++) {
		g.fillStyle = rnd() > .5 ? "rgba(255,255,255,0.18)" : "rgba(0,0,0,0.08)";
		g.fillRect(rnd() * w | 0, rnd() * h | 0, 1, 1);
	}
	g.fillStyle = "rgba(20,16,32,0.18)";
	g.fillRect(w - 4, 0, 4, h);
	g.fillStyle = p.wall;
	g.fillRect(0, h - 6, w, 6 + pad);
	if (pad) for (let x = 0; x < w; x += 4) {
		g.fillStyle = x / 4 % 2 === 0 ? p.accent : "#fff6ea";
		g.fillRect(x, h - 2, 4, pad);
	}
	const doorX = w / 2 - 5 | 0;
	g.fillStyle = "#2a242c";
	g.fillRect(doorX, h - 6, 10, 6 + Math.min(pad, 2));
	g.fillStyle = p.win;
	for (let x = 6; x < w - 10; x += 14) {
		if (Math.abs(x - doorX) < 12) continue;
		g.fillRect(x, h - 5, 6, 4);
	}
	for (let y = 6; y < h - 14; y += 12) for (let x = 6; x < w - 8; x += 14) {
		g.fillStyle = p.win;
		g.fillRect(x, y, 7, 5);
		g.fillStyle = "rgba(255,255,255,0.35)";
		g.fillRect(x, y, 2, 2);
	}
	g.fillStyle = "#9aa3b0";
	g.fillRect(8, 6, 8, 6);
	g.fillStyle = "#6e7784";
	g.fillRect(11, 6, 2, 6);
	g.fillRect(8, 8, 8, 2);
	if (style === "diner") {
		g.fillStyle = "#c4493a";
		g.fillRect(4, 8, w - 8, 6);
		g.fillStyle = "#fff6ea";
		g.fillRect(6, 10, w - 12, 2);
	}
	if (style === "warehouse") {
		g.fillStyle = "#e0a030";
		g.fillRect(4, 4, 14, 6);
		g.fillStyle = "#5c636c";
		g.fillRect(w - 18, 8, 12, 10);
	}
	return c;
}
function sheet(w, h) {
	const c = document.createElement("canvas");
	c.width = w;
	c.height = h;
	const g = c.getContext("2d");
	if (!g) throw new Error("sprite");
	g.imageSmoothingEnabled = false;
	return {
		c,
		g
	};
}
function Home() {
	const ref = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		const el = ref.current;
		if (!el) return;
		return mountGame(el);
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		ref,
		className: "game-root",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "stage",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
					id: "game-canvas",
					className: "game-canvas",
					width: 384,
					height: 216
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				id: "hud",
				className: "hud is-hidden",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "hud-top",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mission-card panel",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								id: "mission-kicker",
								className: "kicker",
								children: "Миссия 1/6"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								id: "mission-text",
								className: "mission-text",
								children: "Возьми пейджер"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "stat-col",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "stat panel",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									id: "money-val",
									className: "money-val",
									children: "$0"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "hp-row",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, {
											size: 14,
											"aria-hidden": "true"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "hp-track",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												id: "hp-fill",
												className: "hp-fill"
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											id: "hp-num",
											className: "hp-num",
											children: "100"
										})
									]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "icon-row",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										id: "sound-btn",
										type: "button",
										className: "icon-btn sound-btn",
										"aria-label": "Звук",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Volume2, {
											className: "icon-on",
											"aria-hidden": "true"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VolumeX, {
											className: "icon-off",
											"aria-hidden": "true"
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										id: "map-btn",
										type: "button",
										className: "icon-btn",
										"aria-label": "Карта",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Map, {
											size: 18,
											"aria-hidden": "true"
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										id: "touch-toggle",
										type: "button",
										className: "icon-btn text-btn",
										"aria-label": "Стик",
										children: "Стик"
									})
								]
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "minimap-wrap panel",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
							id: "minimap",
							className: "minimap",
							width: 108,
							height: 92
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "map-caption",
							children: "карта"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						id: "hint",
						className: "hint panel is-hidden"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						id: "banner",
						className: "banner panel is-hidden"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				id: "dialog",
				className: "dialog panel is-hidden",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
						id: "portrait",
						className: "portrait",
						width: 32,
						height: 32
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "dlg-copy",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							id: "dlg-name",
							className: "dlg-name",
							children: "Кекс"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							id: "dlg-text",
							className: "dlg-text"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						id: "dlg-next",
						type: "button",
						className: "dlg-next",
						children: "Дальше"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				id: "touch-ui",
				className: "touch is-hidden",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					id: "joy",
					className: "joy",
					"aria-hidden": "true",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						id: "joy-knob",
						className: "joy-knob"
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "touch-actions",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "pad-row",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								id: "btn-horn",
								type: "button",
								className: "pad pad-small is-hidden",
								children: "Гудок"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								id: "btn-brake",
								type: "button",
								className: "pad pad-small is-hidden",
								children: "Тормоз"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							id: "btn-act",
							type: "button",
							className: "pad",
							children: "Войти"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							id: "btn-atk",
							type: "button",
							className: "pad pad-atk",
							children: "Удар"
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				id: "fade",
				className: "fade"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				id: "map-overlay",
				className: "overlay is-hidden",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "map-card panel",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "map-head",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Район, река, лес" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								id: "close-map",
								type: "button",
								className: "btn-ghost",
								children: "Закрыть"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
							id: "bigmap",
							className: "bigmap",
							width: 344,
							height: 288
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "fine",
							children: "Жёлтая точка — ты. Ромб — цель. Повторное нажатие на миникарту тоже закрывает карту."
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				id: "end-screen",
				className: "overlay is-hidden",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "end-card panel",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							id: "end-title",
							children: "Рассвет"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							id: "end-copy",
							className: "end-copy"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "btn-row",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								id: "retry-btn",
								type: "button",
								className: "btn-primary",
								children: "Ещё смена"
							})
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				id: "start-screen",
				className: "overlay",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "start-card panel",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "logo",
							children: "Кейс на районе"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "tagline",
							children: "Кекс просыпается после чужой вечеринки. На пейджере — дядя Коля, пропавший кейс и рассвет, который лучше встретить в лесу, а не в багажнике."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
							className: "help",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("kbd", { children: "W" }),
									" ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("kbd", { children: "A" }),
									" ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("kbd", { children: "S" }),
									" ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("kbd", { children: "D" }),
									" или стик — ходьба и руль"
								] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("kbd", { children: "E" }), " / Войти — дверь, разговор, сесть в тачку"] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("kbd", { children: "Пробел" }), " — удар пешком, тормоз за рулём. Кнопка «Газ» жмёт педаль."] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Миникарта открывает весь район: кварталы, реку и лес за мостом." })
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "btn-row",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								id: "start-btn",
								type: "button",
								className: "btn-primary",
								children: "Start"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								id: "continue-btn",
								type: "button",
								className: "btn-ghost",
								disabled: true,
								children: "Продолжить"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "fine",
							children: "Новая игра. Прогресс миссии пишется сам — кнопка «Продолжить» подхватит смену."
						})
					]
				})
			})
		]
	});
}
//#endregion
export { Home as component };
